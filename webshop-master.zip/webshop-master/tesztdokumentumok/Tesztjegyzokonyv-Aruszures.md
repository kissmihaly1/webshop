# Tesztjegyzőkönyv-Áruszűrés

Az alábbi tesztdokumentum a WEBSHOP projekthez tartozó 9.3.15. Árukeresés kezeléséhez tartozó üzleti logika, 9.3.17. Áruszűrők kezeléséhez tartozó üzleti logika funkcióihoz készült. Felelőse: Allaga Dóra 

## 1. Teszteljárások (TP)

### 1.1. Keresés funkció tesztelése 
- Azonosító: TP-01
- Tesztesetek: TC-01, TC-02
- Leírás: keresés funkció tesztelése
    0. lépés: Nyissuk meg az alkalmazást, jelentkezzünk be, automatikusan a Termékek menühöz kerülünk.
    1. lépés: A Keresés szövegbeviteli mezőbe írjuk be a STRING-et
    2. lépés: Nyomjuk meg az Enter billentyűt.
    3. lépés: Ellenőrizzük az eredményt. Elvárt eredmény: csak a beírt áru jelenik meg a listázásban.

### 1.2. Árszűrés funkció tesztelése 
- Azonosító: TP-02
- Tesztesetek: TC-01, TC-02
- Leírás: árszűrés funkció tesztelése
    0. lépés: Nyissuk meg az alkalmazást, jelentkezzünk be, automatikusan a Termékek menühöz kerülünk.
    1. lépés: A Min Ft számbeviteli mezőbe írjuk be a NUMBER1-t.
    2. lépés: A Max Ft számbeviteli mezőbe írjuk be a NUMBER2-t.
    3. lépés: Nyomjuk meg a Szűrés gombot.
    4. lépés: Ellenőrizzük az eredményt. Elvárt eredmény: csak a megadott intervallumba eső árú termékek jelennek meg a listázásban.

### 1.3. Árszűrés törlése funkció tesztelése
- Azonosító: TP-03
- Tesztesetek: TC-01
- Leírás: árszűrés törlése funkció tesztelése
    0. lépés: Nyissuk meg az alkalmazást, jelentkezzünk be, automatikusan a Termékek menühöz kerülünk.
    1. lépés: A Min Ft számbeviteli mezőbe írjuk be a NUMBER1-t.
    2. lépés: A Max Ft számbeviteli mezőbe írjuk be a NUMBER2-t.
    3. lépés: Nyomjuk meg a Szűrés gombot.
    4. lépés: Nyomjunk a Törlés gombra.
    5. lépés: Ellenőrizzük az eredményt. Elvárt eredmény: A törlés gomb hatására újra megjelenik az összes listázott elem. 

## 2. Tesztesetek (TC)

### 2.1. Keresés funkció tesztesetei

#### 2.1.1. TC-01
- TP: TP-01
- Leírás: keresés funkció tesztelése 
- Bemenet: STRING = "Cukor"
- Művelet: nyomjuk meg az Enter billentyűt.
- Elvárt kimenet: csak a "Cukor" áru jelenik meg a listázásban.

#### 2.1.2. TC-02
- TP: TP-01
- Leírás: keresés funkció tesztelése
- Bemenet: STRING = "XD"
- Művelet: nyomjuk meg az Enter billentyűt.
- Elvárt kimenet: "Nincs ilyen áru" felirat megjelenése és nincsenek áruk listázva.

### 2.2. Árszűrés funkció tesztesetei

#### 2.2.1. TC-01
- TP: TP-02
- Leírás: árszűrés funkció tesztelése 
- Bemenet: NUMBER1 = 333, NUMBER2 = 400
- Művelet: nyomjuk meg a Szűrés gombot.
- Elvárt kimenet: Csak a "Cukor", "Uborka", "Alma", "Borsó" jelenik meg a listázásban.

#### 2.2.2. TC-02
- TP: TP-02
- Leírás: árszűrés funkció tesztelése
- Bemenet: NUMBER1 = "D", Number2 = 333
- Művelet: nyomjuk meg a Szűrés gombot.
- Elvárt kimenet: "Please enter a number" error felirat jelenik meg a beviteli mező alatt.

### 2.3. Árszűrés törlése funkció tesztesetei

#### 2.3.1. TC-01
- TP: TP-03
- Leírás: árszűrés törlése funkció tesztelése
- Bemenet: NUMBER1 = 333, NUMBER2 = 400
- Művelet: nyomjuk meg a Szűrés gombot, majd nyomjuk meg a Törlés gombot.
- Elvárt kimenet: A törlés gomb hatására újra megjelenik az összes termék a listázásban.

## 3. Tesztriportok (TR)

### 3.1. Keresés funkció tesztriportjai

#### 3.1.1. TR-01 (TC-01)
- TP: TP-01
    1. lépés: "Cukor"-t beírtam
    2. lépés: Enter billentyűt lenyomtam
    3. lépés: helyes eredményt kaptam (csak a Cukor áru listázva)
    

#### 3.1.2. TR-02 (TC-02)
- TP: TP-01
    1. lépés: "XD"-t beírtam
    2. lépés: Enter billentyűt lenyomtam
    3. lépés: helyes eredményt kaptam ("Nincs ilyen áru" felirat megjelenve és nincsenek áruk listázva)

### 3.2 Árszűrés funkció tesztriportjai

#### 3.1.1. TR-01 (TC-01)
- TP: TP-02
    1. lépés: 333-t beírtam, 400-at beírtam
    2. lépés: Szűrés gombra rányomtam
    3. lépés: helyes eredményt kaptam (csak a "Cukor", "Uborka", "Alma", "Borsó" termékek jelentek meg a listázásban)
    

#### 3.1.2. TR-02 (TC-02)
- TP: TP-02
    1. lépés: "D"-t beírtam, 333-at beírtam
    2. lépés: Szűrés gombra rányomtam
    3. lépés: helyes eredményt kaptam ("Please enter a number" error felirat jelenik meg a beviteli mező alatt)

### 3.3 Árszűrés törlése funkció tesztriportjai

#### 3.1.1. TR-01 (TC-01)
- TP: TP-03
    1. lépés: 333-t beírtam, 400-at beírtam
    2. lépés: Szűrés gombra rányomtam
    3. lépés: Törlés gombra rányomtam
    4. lépés: helyes eredményt kaptam (A törlés gomb hatására újra megjelenik az összes termék a listázásban)

    