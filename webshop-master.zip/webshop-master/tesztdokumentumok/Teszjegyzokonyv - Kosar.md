# Tesztjegyzőkönyv- Kosár kezelése

Az alábbi tesztdokumentum a WEBSHOP projekthez tartozó 9.3.9. Kosár kezeléséhez tartozó üzleti logika (listázása, módosítása, létrehozása, törlése) funkcióihoz készült. Felelőse: Dehnhardt Tom Patrick

## 1. Teszteljárások (TP)

### 1.1. Kosár feltöltés tesztelése

- Azonosító: TP-01
- Tesztesetek: TC-01, TC-02
- Leírás: kosár feltöltésének teszteljárása
  1. lépés: Nyissuk meg az alkalmazást, és a Termékek oldalon válasszunk ki egy tetszőleges terméket
  2. lépés: A kiválasztott termék Mennyiség mezőbe írjunk be egy tetszőleges számot ami nem nagyobb a raktáron lévő számtól
  3. lépés: Nyumjuk meg a Kosárba gombot
  4. lépés: Ellenőrizzük az eredményt. Elvárt eredmény: A kosár oldalon látható lesz mennyit tettünk kiválasztott termékből kosarunkba

### 1.2. Kosárban található áruk törlése tesztelése

- Azonosító: TP-02
- Tesztesetek: TC-01
- Leírás: kosárban található áru/áruk törlésének teszteljárása
  1. lépés: Nyissuk meg az alkalmazást, és a Kosár oldalon válasszuk ki a törölni kivánt terméket
  2. lépés: Nyomjuk meg a pirossal jelölt Törlés gombot
  3. lépés: Ellenőrizzük az eredményt. Elvárt eredmény: A kosárból törlödött a kiválasztott termék

### 1.3. Kosárban található áruk módosítása tesztelése

- Azonosító: TP-03
- Tesztesetek: TC-01
- Leírás: kosárban található áru/áruk módosításának teszteljárása
  1. lépés: Nyissuk meg az alkalmazást, és a Kosár oldalon válasszuk ki a módositani kivánt terméket
  2. lépés: A Kosárban lévő mezőben láthajuk mennyit választottunk ki az adott termékből és most megadhatunk egy új mennyiséget
  3. lépés: Nyomjuk meg a Módosít gombot
  4. lépés: Ellenőrizzük az eredményt. Elvárt eredmény: A termék kosárban lévő mennyisége változott

## 2. Teszesetek (TC)

### 2.1. Kosár feltöltés tesztelése

#### 2.1.1. TC-01

- TP: TP-01
- Leírás: kosár feltöltésének tesztelése
- Bemenet: Áru = Lazac; Mennyiség = 4;
- Művelet: nyomjuk meg az Kosárba gombot
- Elvárt kimenet: a kosár oldalon a kosárban mező tartalma = 4

#### 2.1.2. TC-02

- TP: TP-01
- Leírás: kosár feltöltésének tesztelése
- Bemenet: Áru = Alma; Mennyiség = 12;
- Művelet: nyomjuk meg az Kosárba gombot
- Elvárt kimenet: a mennyiség mező figyelmeztet minket, hogy a mennyiség 10-nél kisebbnek vagy egyenlőnek kell lennie (mert almából csak 10 van raktáron)

### 2.2. Kosárban található áruk törlése tesztelése

#### 2.2.1. TC-01

- TP: TP-02
- Leírás: kosárban található áru/áruk törlésének tesztelése
- Bemenet: Áru = Uborka; Kosárban = 1
- Művelet: nyomjuk meg az Törlés gombot
- Elvárt kimenet: az Uborka nevű áru törlödik a kosárból

### 2.3. Kosárban található áruk módosítása tesztelése

#### 2.3.1. TC-01

- TP: TP-03
- Leírás: négyzetre emelés funkció tesztelése
- Bemenet: Áru = Uborka; Kosárban = 1
- Művelet: a kosárban mezőbe írjunk egy másik számot majd nyomjuk meg a Módosít gombot
- Elvárt kimenet: a kosárban mező tartalma annyi lesz amennyit az előbb beirtunk

## 3. Tesztriportok (TR)

### 3.1. Kosár feltöltés tesztriportjai

#### 3.1.1. TR-01 (TC-01)

- TP: TP-01
  1. lépés: Kiválasztott termékem Cukor
  2. lépés: Mennyiség mezőbe beirtam 2
  3. lépés: A kosárba gomb megnyomás
  4. lépés: Helyes eredményt kaptam a kosárban látható, hogy betettem 2 cukrot

#### 3.1.2. TR-02 (TC-02)

- TP: TP-01
  1. lépés: Kiválasztott termékem Cukor
  2. lépés: Mennyiség mezőbe beirtam 9
  3. lépés: A kosárba gomb megnyomás
  4. lépés: Helyes eredményt kaptam a mennyiség 4-nél kisebbnek vagy egyenlőnek kell lennie (mert cukorból csak 4 van raktáron)

### 3.2. Kosárban található áruk törlése tesztriportjai

#### 3.2.1. TR-01 (TC-01)

- TP: TP-02
  1. lépés: Kiválasztott termékem Paprika
  2. lépés: A törlés gomb megnyomás
  3. lépés: Helyes eredményt kaptam a Paprika termék törlődött a kosárból

### 3.3. Kosárban található áru/áruk módosításának tesztriportjai

#### 3.3.1. TR-01 (TC-01)

- TP: TP-03
  1. lépés: Módosítani kivánt termékem a Banán
  2. lépés: A kosárban mező átírása 1-ről 3-ra
  3. lépés: A Módosít gomb megnyomás
  4. lépés: Helyes eredményt kaptam a Banán termékböl már 3 van a kosárban
