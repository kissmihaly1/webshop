# Tesztjegyzőkönyv- Felhasználók kezelése

Az alábbi tesztdokumentum a WEBSHOP projekthez tartozó 9.3.4. Felhasználók kezeléséhez tartozó üzleti logika (adatok listázása, módosítása, létrehozása, törlése) funkcióihoz készült. Feladat felelőse: Sziver Bence Dávid 


## 1. Teszteljárások (TP)

### 1.1. Regisztráció funkció tesztelése 
- Azonosító: TP-01
- Tesztesetek: TC-01, TC-02
- Leírás: Regisztráció funkció tesztelése
    0. lépés: Nyissuk meg az alkalmazást, és indítsuk el a regisztráció funkciót
    1. lépés: Az E-mail cím szövegbeviteli mezőbe írjunk be a tesztuser@gmail.com szöveget
    2. lépés: A Teljes név szövegbeviteli mezőbe írjunk be a Teszt User szöveget
    3. lépés: A Település szövegbeviteli mezőbe írjunk be a Teszt város szöveget
    4. lépés: Az Utca szövegbeviteli mezőbe írjunk be a Teszt utca szöveget
    5. lépés: A Házszám szövegbeviteli mezőbe írjunk be a 22 számot
    6. lépés: A Jelszó szövegbeviteli mezőbe írjunk be a tesztjelszo szöveget
    7. lépés: A Jelszó újra szövegbeviteli mezőbe írjunk be a tesztjelszo szöveget
    8. lépés: Nyomjuk meg a Regisztrálás gombot 
    9. lépés: Ellenőrizzük az eredményt. Elvárt eredmény: Teszt User sikeres regisztrálása, átirányítás bejelentkezés oldalra


### 1.2. Adatok módosítása funkció tesztelése 
- Azonosító: TP-02
- Tesztesetek: TC-01, TC-02
- Leírás: Adatok módosítása funkció tesztelése
    0. lépés: Nyissuk meg az alkalmazást, és indítsuk el a profil funkciót
    1. lépés: A Új jelszó szövegbeviteli mezőbe írjunk be a tesztnewjelszo szöveget
    2. lépés: A Jelszó újra szövegbeviteli mezőbe írjunk be a tesztnewjelszo szöveget
    3. lépés: A Név szövegbeviteli mezőbe írjunk be a Teszt New User szöveget
    4. lépés: A Település szövegbeviteli mezőbe írjunk be a Teszt New város szöveget
    5. lépés: Az Utca szövegbeviteli mezőbe írjunk be a Teszt New utca szöveget
    6. lépés: A Házszám szövegbeviteli mezőbe írjunk be a 33 számot
    7. lépés: Nyomjuk meg a Módosítás gombot 
    8. lépés: Ellenőrizzük az eredményt. Elvárt eredmény: Visszajelzés az adatok sikeres módosításáról, Felhasználó adatainak frissítése az új értékekkel

### 1.3. Fiók törlése funkció tesztelése
- Azonosító: TP-03
- Tesztesetek: TC-01
- Leírás: Fiók törlése funkció tesztelése
    0. lépés: Nyissuk meg az alkalmazást, és indítsuk el a profil funkciót
    1. lépés: Nyomjuk meg a Fiók törlése gombot 
    2. lépés: Ellenőrizzük az eredményt. Elvárt eredmény: Megerősítés kérése, Igen esetén átirányítás bejelentkezés oldalra, Nem esetén a Fiók törlése gomb visszaállítása


## 2. Tesztesetek (TC)

### 2.1. Regisztráció funkció tesztesetei

#### 2.1.1. TC-01
- TP: TP-01
- Leírás: regisztráció funkció tesztelése 
- Bemenet: E-mail cím = tesztuser@gmail.com ; Teljes név = Teszt User ; Település = Teszt város ; Utca = Teszt utca ; Házszám = 22 ; Jelszó = tesztjelszo ; Jelszó újra = tesztjelszo 
- Művelet: nyomjuk meg az Regisztráció gombot 
- Elvárt kimenet: Átirányítás a bejelentkezés oldalra, visszajelzés sikeres regisztrációról

#### 2.1.2. TC-02
- TP: TP-01
- Leírás: regisztráció funkció tesztelése 
- Bemenet: E-mail cím = "" ; Teljes név = "" ; Település = "" ; Utca = "" ; Házszám = -1 ; Jelszó = abc ; Jelszó újra = cba 
- Művelet: nyomjuk meg a Regisztráció gombot 
- Elvárt kimenet: Hibaüzenetek: Üres mezők kitöltése kötelező ; Házszám nem vehet fel negatív értéket ; Nem egyeznek a jelszavak ; Legalább 5 karakter hosszú jelszó szükséges


### 2.2. Adatok módosítása funkció tesztesetei

#### 2.2.1. TC-01
- TP: TP-02
- Leírás: Adatok módosítása funkció tesztelése 
- Bemenet: Új jelszó = tesztnewjelszo ; Jelszó újra = tesztnewjelszo ; Név = Teszt New User ; Település = Teszt New város ; Utca = Teszt New utca ; Házszám = 33  
- Művelet: nyomjuk meg a Módosítás gombot 
- Elvárt kimenet: Visszajelzés az adatok sikeres módosításáról, Felhasználó adatainak frissítése az új értékekkel

#### 2.2.2. TC-02
- TP: TP-02
- Leírás: Adatok módosítása funkció tesztelése 
- Bemenet: Új jelszó = abc ; Jelszó újra = cba ; Név = "" ; Település = "" ; Utca = "" ; Házszám = -1  
- Művelet: nyomjuk meg a Módosítás gombot 
- Elvárt kimenet: Hibaüzenetek: Házszám nem vehet fel negatív értéket ; Nem egyeznek a jelszavak ; Legalább 5 karakter hosszú jelszó szükséges

### 2.3. Fiók törlése funkció tesztesetei

#### 2.3.1. TC-01
- TP: TP-03
- Leírás: Fiók törlése funkció tesztelése
- Művelet: nyomjuk meg a Fiók törlése gombot 
- Elvárt kimenet: Megerősítés kérése, Igen esetén átirányítás bejelentkezés oldalra, Nem esetén a Fiók törlése gomb visszaállítása

## 3. Tesztriportok (TR)

### 3.1. Regisztráció funkció tesztriportjai

#### 3.1.1. TR-01 (TC-01)
- TP: TP-01
    1. lépés: Regisztráció bemeneti mezőkbe E-mail cím = tesztuser@gmail.com ; Teljes név = Teszt User ; Település = Teszt város ; Utca = Teszt utca ; Házszám = 22 ; Jelszó = tesztjelszo ; Jelszó újra = tesztjelszo értékeket beírtam
    2. lépés: Regisztrálás billentyűt lenyomtam
    3. lépés: Helyes eredményt kaptam (sikeres regisztráció szöveg kiírva, felhasználó átirányítva a bejelentkezés oldalra)

#### 3.1.2. TR-01 (TC-02)
- TP: TP-01
    1. lépés: Regisztráció bemeneti mezőkbe E-mail cím = "" ; Teljes név = "" ; Település = "" ; Utca = "" ; Házszám = -1 ; Jelszó = abc ; Jelszó újra = cba értékeket beírtam
    2. lépés: Regisztrálás billentyűt lenyomtam
    3. lépés: Helyes eredményt kaptam (Hibaüzenetek: Üres mezők kitöltése kötelező!, Házszám értéke legyen nagyobb vagy egyenlő, mint 1!, Jelszó legalább 5 karakter!, Jelszavak nem egyeznek!)

### 3.2. Adatok módosítása funkció tesztriportjai

#### 3.2.1. TR-01 (TC-01)
- TP: TP-02
    1. lépés: Adatok módosítása bemeneti mezőkbe Új jelszó = tesztnewjelszo ; Jelszó újra = tesztnewjelszo ; Név = Teszt New User ; Település = Teszt New város ; Utca = Teszt New utca ; Házszám = 33 értékeket beírtam
    2. lépés: Módosítás billentyűt lenyomtam
    3. lépés: Helyes eredményt kaptam (felhasználó adatai módosultak, profilján frissültek)

#### 3.2.2. TR-01 (TC-02)
- TP: TP-02
    1. lépés: Adatok módosítása bemeneti mezőkbe Új jelszó = abc ; Jelszó újra = cba ; Név = "" ; Település = "" ; Utca = "" ; Házszám = -1 értékeket beírtam
    2. lépés: Módosítás billentyűt lenyomtam
    3. lépés: Helyes eredményt kaptam (Hibaüzenetek: Üres mezők kitöltése kötelező!, Házszám értéke legyen nagyobb vagy egyenlő, mint 1!, Jelszó legalább 5 karakter!, Jelszavak nem egyeznek!)

### 3.3. Fiók törlése funkció tesztriportjai

#### 3.3.1. TR-01 (TC-01)
- TP: TP-03
    1. lépés: Felhasználó profilját megnyitottam
    2. lépés: Fiók törlése és Nem billentyűket, majd Fiók törlése és Igen billentyűket lenyomtam
    3. lépés: Helyes eredményt kaptam (Törlés megerősítése üzenet, Igen és Nem gomb megjelent, Nem gombra kattintva visszaállítja a Fiók törlése gombot, Igen gombra kattintva a fiók törlődött és a felhasználó át lett irányítva a Bejelentkezés oldalra)