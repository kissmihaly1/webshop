# Tesztjegyzőkönyv- Felhasználók kezelése

Az alábbi tesztdokumentum a WEBSHOP projekthez tartozó 9.3.1. Felhasználói munkamenet üzleti logikája több jogosultsági szinttel (admin, vásárló) funkcióihoz készült. Feladat felelőse: Tomity Jaroslav


## 1. Teszteljárások (TP)

### 1.1. Bejelentkezés funkció tesztelése
- Azonosító: TP-01
- Tesztesetek: TC-01, TC-02
- Leírás: Bejelentkezés funkció tesztelése
    0. lépés: Nyissuk meg az alkalmazást, és indítsuk el a bejelentkezés funkciót
    1. lépés: Az E-mail cím szövegbeviteli mezőbe írjunk be a tesztuser@gmail.com szöveget
    2. lépés: A Jelszó szövegbeviteli mezőbe írjunk be a tesztjelszo szöveget
    2. lépés: Nyomjuk meg az Bejelentkezés gombot 
    3. lépés: Ellenőrizzük az eredményt. Elvárt eredmény: Felhasználó bejelentkeztetése, átirányítás a termékek oldalra

### 1.2. Kijelentkezés funkció tesztelése
- Azonosító: TP-02
- Tesztesetek: TC-01
- Leírás: Kijelentkezés funkció tesztelése
    0. lépés: Nyissuk meg az alkalmazást, és jelentkezzünk be
    1. lépés: Nyomjuk meg a Kijelentkezés gombot 
    2. lépés: Ellenőrizzük az eredményt. Elvárt eredmény: Felhasználó kijelentkeztetése, átirányítás a bejelentkezés oldalra

## 2. Tesztesetek (TC)

### 2.1. Bejelentkezés funkció tesztesetei

#### 2.1.1. TC-01
- TP: TP-01
- Leírás: bejelentkezés funkció tesztelése
- Bemenet: E-mail cím = tesztuser@gmail.com ; Jelszó = tesztjelszo
- Művelet: nyomjuk meg a Bejelentkezés gombot 
- Elvárt kimenet: Felhasználó átirányítása a Termékek oldalra

#### 2.1.2. TC-02
- TP: TP-01
- Leírás: bejelentkezés funkció tesztelése
- Bemenet: E-mail cím = "tesztuser@gmail.com" ; Jelszó = "rosszjelszo"
- Művelet: nyomjuk meg a Bejelentkezés gombot 
- Elvárt kimenet: Hibaüzenet: Érvénytelen belépési adatok! Ellenőrizze a megadott emailt és jelszót!

### 2.2. Kijelentkezés funkció tesztesetei

#### 2.2.1. TC-01
- TP: TP-02
- Leírás: Kijelentkezés funkció tesztelése
- Művelet: nyomjuk meg a Kijelentkezés gombot 
- Elvárt kimenet: Felhasználó kijelentkeztetése, átirányítás a bejelentkezés oldalra

## 3. Tesztriportok (TR)

### 3.1. Bejelentkezés funkció tesztriportjai

#### 3.1.1. TR-01 (TC-01)
- TP: TP-01
    1. lépés: tesztuser@gmail.com-t és tesztjelszo-t beírtam
    2. lépés: Bejelentkezés billentyűt lenyomtam
    3. lépés: helyes eredményt kaptam (bejelentkeztette a felhasználót)

### 3.2. Kijelentkezés funkció tesztriportjai

#### 3.2.1. TR-02 (TC-01)
- TP: TP-02
    1. lépés: tesztuser felhasználót bejelentkeztettem
    2. lépés: Kijelentkezés billentyűt lenyomtam
    3. lépés: helyes eredményt kaptam (kijelentkeztette a felhasználót és átirányította a bejelentkezés oldalra)