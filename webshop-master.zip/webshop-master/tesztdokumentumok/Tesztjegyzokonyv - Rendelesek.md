# Tesztjegyzőkönyv- Felhasználók kezelése

Az alábbi tesztdokumentum a WEBSHOP projekthez tartozó 9.3.12.  Rendelések kezeléséhez kapcsolódó üzleti logika (listázása, létrehozása)
Felelős: Sziver Bence Dávid


## 1. Teszteljárások (TP)

### 1.1. Rendelés létrehozás tesztelése
- Azonosító: TP-01
- Tesztesetek: TC-01, TC-02
- Leírás: Rendelés létrehozás funkció tesztelése
    0. lépés: Nyissuk meg az alkalmazást, és indítsuk el a kosár funkciót, amelyben két termék van: Kifli, Cukor.
    1. lépés: Kattintsunk a Rendelés gombra.
    2. lépés: Kattintsunk az igen gombra.
    3. lépés: Ellenőrizzük az eredményt. Elvárt eredmény: Sikeres rendelés, átirányítás a rendelések oldalra.



### 1.2. Rendelés listázás tesztelése
- Azonosító: TP-02
- Tesztesetek: TC-01
- Leírás: Rendelés listázás funkció tesztelése
    0. lépés: Nyissuk meg az alkalmazást, és indítsuk el a rendelés funkciót.
    1. lépés: Válasszunk egy rendelést a listából.
    3. lépés: Ellenőrizzük az eredményt. Elvárt eredmény: A rendelés termékeinek listázása, az adott oldalon.


## 2. Tesztesetek (TC)

### 2.1. Rendelés létrehozása funkció tesztesetei

#### 2.1.1. TC-01
- TP: TP-01
- Leírás: Rendelés létrehozása funkció tesztelése 
- Bemenet: Áru = Kifli, mennyiség = 4.
- Művelet: Nyomjuk meg a rendelés gombot
- Elvárt kimenet: Sikeres rendelés

#### 2.1.2. TC-02
- TP: TP-01
- Leírás: Rendelés létrehozása funkció tesztelése 
- Bemenet: Nincs áru
- Művelet: Nyomjuk meg a rendelés gombot
- Elvárt kimenet: Sikertelen rendelés, és az alábbi felirat: Üres a kosár! Nem lehet rendelni!

### 2.2. Rendelés listázása funkció tesztesetei

#### 2.1.1. TC-01
- TP: TP-01
- Leírás: Rendelés listázása funkció tesztelése 
- Bemenet: -
- Művelet: Nyomjuk meg a rendelések gombot
- Elvárt kimenet: A rendelések sikeresen listázva vannak.


### 3.1. Rendelés létrehozás tesztriportjai

#### 3.1.1. TR-01 (TC-01)

- TP: TP-01
  1. lépés: Kiválasztott termék a kosárban: kifli, 3 db
  2. lépés: A rendelés gomb megnyomás
  3. lépés: Az igen gomb megnyomás
  4. lépés: Helyes eredményt, a rendelés létrejött.

#### 3.1.2. TR-02 (TC-02)

- TP: TP-01
  1. lépés: Kiválasztott termék a kosárban: kifli 3 db, lazac 5db, cukor 1 db.
  2. lépés: A rendelés gomb megnyomás
  3. lépés: Az igen gomb megnyomás
  4. lépés: Helyes eredményt, a rendelés létrejött.

