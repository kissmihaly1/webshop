# Tesztjegyzőkönyv-Árukezelés

Az alábbi tesztdokumentum a WEBSHOP projekthez tartozó 9.3.6. Árukezeléshez tartozó üzleti logika funkcióihoz készült. Felelőse: Kiss Mihály

## 1. Teszteljárások (TP)

### 1.1. Termékhozzáadás funkció tesztelése 
- Azonosító: TP-01
- Tesztesetek: TC-01, TC-02, TC-03
- Leírás: hozzáadás funkció tesztelése
    0. lépés: Nyissuk meg az alkalmazást, jelentkezzünk be adminként, automatikusan a Termékek menühöz kerülünk.
    1. lépés: Görgessünk le a termék hozzáadása részhez.
    2. lépés: Írjuk be a hozzáadandó termék nevét az Id mezőbe.
    3. lépés: Opcionálisan megadhatjuk a termék képének elérési útvonalát, a termék árát és a raktáron levő mennyiséget. Ha nem adunk meg értéket a default értékek String esetén üres string, Int esetén 0 lesz. 
    4. lépés: Nyomjuk meg a hozzáadás gombot.
    5. lépés: Ellenőrizzük az eredményt. Elvárt eredmény: az új termék megjelenik a termékek között.

### 1.2. Termékmódosítás funkció tesztelése 
- Azonosító: TP-02
- Tesztesetek: TC-01, TC-02
- Leírás: módosítás funkció tesztelése
    0. lépés: Nyissuk meg az alkalmazást, jelentkezzünk be adminként, automatikusan a Termékek menühöz kerülünk.
    1. lépés: Keressük ki a módosítani kívánt terméket.
    2. lépés: Az "Image", "Ár" és "Raktáron" mezők automatikusan ki vannak töltve az aktuális értékekkel, a módosítani kívánt attribútum mezőjébe adjuk meg az új értéket.
    3. lépés: Nyomjuk meg a Módosít gombot.
    4. lépés: Ellenőrizzük az eredményt. Elvárt eredmény: a módosítandó termék valóban módosult.

### 1.3. Terméktörlés funkció tesztelése
- Azonosító: TP-03
- Tesztesetek: TC-01
- Leírás: törlés funkció tesztelése
    0. lépés: Nyissuk meg az alkalmazást, jelentkezzünk be adminként, automatikusan a Termékek menühöz kerülünk.
    1. lépés: Keressük ki a törölni kívánt terméket.
    2. lépés: Nyomjuk meg a termékhez tartozó Törlés gombot.
    3. lépés: Ellenőrizzük az eredményt. Elvárt eredmény: a törlendő termék eltűnt a listából. 

## 2. Tesztesetek (TC)

### 2.1. Termékhozzáadás funkció tesztesetei

#### 2.1.1. TC-01
- TP: TP-01
- Leírás: hozzáadás funkció tesztelése 
- Bemenet: ID = "proba_termek", Termék ára= "200"
- Művelet: nyomjuk meg az Enter billentyűt.
- Elvárt kimenet: a termékek között megjelenik "proba_termek" termék, kép nélkül, 200FT-os áron, 0 raktármennyiséggel.

#### 2.1.2. TC-02
- TP: TP-01
- Leírás: hozzáadás funkció tesztelése
- Bemenet: ID = "Cukor"
- Művelet: nyomjuk meg az Enter billentyűt.
- Elvárt kimenet: nem történik semmi, mivel már van ilyen nevű termék.

#### 2.1.3. TC-03
- TP: TP-01
- Leírás: hozzáadás funkció tesztelése
- Bemenet: ID = "termek", Termék ára = "naon ocso", Raktáron = "-69"
- Művelet: nyomjuk meg az Enter billentyűt.
- Elvárt kimenet: "Írjon be egy számot"/"Válasszon 0-nál nem kisebb értéket" error felirat jelenik meg a beviteli mező alatt.

### 2.2. Termékmódosítás funkció tesztesetei

#### 2.2.1. TC-01
- TP: TP-02
- Leírás: módosítás funkció tesztelése 2.1.1. pontban létrehozott terméken
- Bemenet: Raktáron = "5"
- Művelet: nyomjuk meg a Módosít gombot.
- Elvárt kimenet: proba_termek Raktáron attribútuma 5-re módosult, minden más változatlan maradt.

#### 2.2.2. TC-02
- TP: TP-02
- Leírás: módosítás funkció tesztelése 2.1.1. pontban létrehozott terméken
- Bemenet: Ár = ""
- Művelet: nyomjuk meg a Módosít gombot.
- Elvárt kimenet: "Írjon be egy számot" error felirat jelenik meg a beviteli mező alatt.

### 2.3. Terméktörlés funkció tesztesetei

#### 2.3.1. TC-01
- TP: TP-03
- Leírás: törlés funkció tesztelése 2.1.1. pontban létrehozott terméken
- Művelet: nyomjuk meg a Törlés gombot.
- Elvárt kimenet: proba_termek termékünk törlésre került.

## 3. Tesztriportok (TR)

### 3.1. Termékhozzáadás funkció tesztriportjai

#### 3.1.1. TR-01 (TC-01)
- TP: TP-01
    1. lépés: Legörgettem a termékhozzáadás ablakhoz
    2. lépés: ID mezőbe "proba_termek"-et beírtam
    3. lépés: Termék ára mezőbe "200"-at beírtam
    4. lépés: Hozzáadás gombot megnyomtam
    5. lépés: Helyes eredmény, az új termék megjelent a listán
    

#### 3.1.2. TR-02 (TC-02)
- TP: TP-01
  1. lépés: Legörgettem a termékhozzáadás ablakhoz
  2. lépés: ID mezőbe "Cukor"-t beírtam
  3. lépés: Opcionális mezőket üresen hagytam
  4. lépés: Hozzáadás gombot megnyomtam
  5. lépés: Helyes eredmény, az új termék nem jelent meg a listán

#### 3.1.3. TR-03 (TC-03)
- TP: TP-01
  1. lépés: Legörgettem a termékhozzáadás ablakhoz
  2. lépés: ID mezőbe "termek"-et beírtam
  3. lépés: Termék ára mezőbe "naon olcso"-t, Raktáron mezőbe "-69"-et beírtam
  4. lépés: Hozzáadás gombot megnyomtam
  5. lépés: Helyes eredmény, "Írjon be egy számot" hiba megjelent a mező alatt
  
### 3.2 Termékmódosítás funkció tesztriportjai

#### 3.1.1. TR-01 (TC-01)
- TP: TP-02
    1. lépés: kikerestem "proba_termek" termeket
    2. lépés: Raktáron mezőben 0 értéket átirtam 5-re
    3. lépés: Módosít gombot megnyomtam
    4. lépés: Helyes eredmény, a proba_termek Raktáron értéke 5-re módosult, más nem változott
    

#### 3.1.2. TR-02 (TC-02)
- TP: TP-02
  1. lépés: kikerestem "proba_termek" termeket
  2. lépés: Ár mezőből kitöröltem az eredeti 200-at
  3. lépés: Módosít gombot megnyomtam
  4. lépés: Helyes eredmény, "Írjon be egy számot" hiba megjelent a mező alatt, a termék nem módosult

### 3.3 Terméktörlés funkció tesztriportjai

#### 3.1.1. TR-01 (TC-01)
- TP: TP-03
    1. lépés: kikerestem "proba_termek" termeket
    2. lépés: Törlés gombra rányomtam
    3. lépés: Helyes eredmény, "proba_termek" termék megszűnt létezni (F)

    