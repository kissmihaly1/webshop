Bejelentkezési lehetőségek:

admin:
email: admin@gmail.com
jelszó: jelszo

user:
email: user@gmail.com
jelszó: jelszo

Új user regisztráció is lehetséges.

Webapp elérése:
157.230.102.109:8080

