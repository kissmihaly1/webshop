# Webshop Projektterv 2022

## 1. Összefoglaló 

A projekt célja egy webshop webapplikáció készítése. Letisztult felületen keresztül biztosít a felhasználóknak egy internetes áruházat, ahol ruháktól kezdve élelmiszereken át a legkülönfélébb árukat teszi kínálatba. Lehetőség van többek között böngészni, szűrni az áruk között, kosárba helyezni őket, megvásárolni a kosár tartalmát, nyomon követni mikor érkezik meg a rendelt áru, értékelni a kapott árukat. Az árukról részletes információk állnak rendelkezésre.

## 2. Verziók

| Verzió | Szerző(k)                | Dátum        | Státusz         | Megjegyzés                                                    |
|--------|--------------------------|--------------|-----------------|---------------------------------------------------------------|
| 0.1  |     Sziver Bence Dávid    | 2022-09-27 | Tervezet      | Legelső verzió                                              |
| 0.2  |     mindenki     | 2022-10-02 | Előterjesztés      | A projekt menedzsere jónak találta                                            |
| 1.0  |     Sziver Bence Dávid       | 2022-10-10 | Elfogadott      | Gyakorlatvezető által jóváhagyva                                            |
| 1.1  |     Sziver Bence Dávid       | 2022-10-15 | Előterjesztés      | Új csoportmegbeszélések hozzáadása                                          |


Státusz osztályozás:
 - Tervezet: befejezetlen dokumentum, a mérföldkő leadása előtti napokban
 - Előterjesztés: a projekt menedzser bírálatával, a mérföldkő határidejekor
 - Elfogadott: a megrendelő által elfogadva, a prezentáció bemutatásakor

## 3. A projekt bemutatása

Ez a projektterv a Webshop projektet mutatja be, mely 2022-09-20-től 2022-11-27-ig tart. A projekt célja, hogy megfelelő felületet biztosítson a vásárlási feladatok online elvégzésére és az áruk, rendelések, tranzakciók nyilvántartására. Mindezért egy egyszerűen használható, átlátható és hatékonyan működő webalkalmazás fog felelni. A projekten öt fő fejlesztő fog dolgozni, az elvégzett feladatokat pedig négy alkalommal fogjuk prezentálni a megrendelőnek.

### 3.1. Rendszerspecifikáció

A rendszernek képesnek kell lennie arra, hogy a megvásárolható árukat (azok árát, készleten lévő mennyiségét, rövid leírását, várható szállítási idejét), illetve a vásárlásokat nyilvántartsa. A felhasználó tud keresni, szűrni, böngészni az áruk között; kosárba rakhatja őket, meg tudja vásárolni a kosárban tartott termékeit, nyomon tudja követni mikorra várható az áru(k) kiszállítása. A már megrendelt, kiszállított árukat tudja értékelni. Minden funkció a megfelelő felhasználói jogosultság mellett használható, annak függvényében írható, olvasható vagy nem megtekinthető az adat.

### 3.2. Funkcionális követelmények

 - Felhasználói munkamenet megvalósítása több jogosultsági szinttel (admin, vásárló)
 - Felhasználók kezelése (CRUD)
 - Áruk kezelése (CRUD)
 - Kosár kezelése (CRUD)
 - Rendelések kezelése (CRUD)
 - Áruk szűrési funkciói
 - Árukereső funkció
 - Áruértékelő funkció

### 3.3. Nem funkcionális követelmények

 - A kliens oldal platform- és böngészőfüggetlen legyen
 - Reszponzív megjelenés
 - Szenzitív adatokat biztonságosan tároljuk
 - A legfrissebb technológiákat használja a rendszer

## 4. Költség- és erőforrás-szükségletek

Az erőforrásigényünk összesen kb. 22 személynap/fő.

A rendelkezésünkre áll összesen 5 * 70 = 350 pont.


## 5. Szervezeti felépítés és felelősségmegosztás
A projekt megrendelője Dr. Kertész Attila. A Webshop projektet a projektcsapat fogja végrehajtani, amely jelenleg öt fejlesztőből áll. A csapatban csak pályakezdő webprogramozók vannak. Jelenlegi csapattagoknak nincs releváns tapasztalata a webprogramozásban.
 
 - Sziver Bence Dávid (Kezdő)
 - Tomity Jaroslav (Kezdő)
 - Dehnhardt Tom Patrick (Kezdő)
 - Allaga Dóra (Kezdő)
 - Kiss Mihály (Kezdő)



### 5.1 Projektcsapat
A projekt a következő emberekből áll:

|                                                                                                                   | Név                  | E-mail cím (stud-os)       |
|-------------------------------------------------------------------------------------------------------------------|----------------------|----------------------------|
| Megrendelő                                                                                                        | Dr. Kertész Attila   |  keratt@inf.u-szeged.hu.   |
| Felelősségek: Projekt menedzser      									            | Sziver Bence Dávid   |  h776273@stud.u-szeged.hu  |
| Projekt tag                                                            				  	    | Tomity Jaroslav      |  h165220@stud.u-szeged.hu  |
| Projekt tag                                                                                                       | Kiss Mihály          |  h159929@stud.u-szeged.hu  |
| Projekt tag                                                                                                       | Allaga Dóra          |  h042569@stud.u-szeged.hu  |
| Projekt tag                                                                                                       | Dehnhardt Tom Patrick|  h754348@stud.u-szeged.hu  |


## 6. A munka feltételei

### 6.1. Munkakörnyezet
A projekt a következő munkaállomásokat fogja használni a munka során:
 -  Munkaállomások: 4 db PC Windows 10-es, illetve 1 db MacOS operációs rendszerrel.
 -  Asztali számítógép (CPU: Ryzen 5 1600AF, RAM: 16GB, GPU: Nvidia GTX1650S)
 -  Asus ROG Strix G15 laptop (CPU: Ryzen 7 4800H, RAM: 16GB, GPU: Nvidia GTX1650)
 -  Macbook Air laptop (CPU: M1 chip, RAM: 8GB, GPU: Integrált)
 -  Dell Inspiron 17R-5737 Laptop (CPU: Intel Core i7-4500U, RAM: 8GB, GPU: AMD Radeon HD 8870M)
 -  Dell Inspiron 5567 laptop (CPU: i5-7200U, RAM: 8GB, GPU: AMD Radeon R7 M440)

A projekt a következő technológiákat/szoftvereket fogja használni a munka során: 
 - IaaS és PostgreSQL adatbázis szolgáltatás
 - Spring Boot
 - IntelliJ IDEA
 - Git verziókövető (GitLab)


### 6.2. Rizikómenedzsment


|  Kockázat                                    | Leírás                                                                                                                                                                                  | Valószínűség | Hatás  |
|---------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------|--------|
| Betegség	    | Ha az egyik tag betegségben szenved, akadályozhatja, felfüggesztheti a tag munkavégzését. Megoldás: Megbeszélés szerint feladat átcsoportosítása.	| Nagy	       | Erős   |
| Szoftver-hardver hiba  | Ha az egyik tag problémákba ütközik, akkor megpróbáljuk minél jobban helyettesíteni.Megoldás: Első körben megpróbáljuk helyettesíteni a problémás gépet/szoftvert. Ha nem megy, akkor feladatok átcsoportosítása.	| Közepes      | Erős	|
| Kommunikációs fennakadás a csapattagokkal  | A csapattagok között nem elégséges az információ áramlás, nem pontosan, esetleg késve vagy nem egyértelműen tájékoztatjuk egymást. Megoldás: még gyakoribb megbeszélések és ellenőrzések	| Kis	       | Közepes|
| Tag kiesés	    | Tag kiesése, valami váratlan esemény miatt, illetve ha a tag kilép. Megoldás: A kieső tag feladatai kiosztása, projekt menedzser megfelelő illetékeseknek jelzi a problémát. Költségpont csökkentése.	| Kis	       | Erős	|
| Tag hanyagság     | Ha egy tag nem végzi megfelelően a feladatait, határidőket nem tartja be. Megoldás: Első körben a csapat többi tagja a projekt menedzser vezetésével figyelmezteti a hanyag tagot. Ha nem alkalmazkodik ezek után sem, akkor a projekt menedzser szól az illetékeseknek.	| Kis	       | Erős	|
| Rosszul elosztott feladatok| Ha aránytalanul lettek elosztva a feladatok. Megoldás: Csapatmegbeszélés során átbeszéljük, és meghatározzuk hogy hogyan lenne igazságos az elosztás.	| Kis	       |Gyenge  |


## 7. Jelentések

### 7.1. Munka menedzsment
A munkát Sziver Bence Dávid koordinálja. Fő feladata, hogy folyamatosan egyeztessen a csapattagokkal az előrehaladásról és a fellépő problémákról, esetlegesen a megoldásban is segítséget nyújhat a projekt csúszásának elkerülése végett. További feladata a heti szinten tartandó csoportgyűlések időpontjának és helyszínének leszervezése, erről Discordon tájékoztatja a projektcsapatot.

### 7.2. Csoportgyűlések

1. megbeszélés:
 - Időpont: 2021.09.19.
 - Hely: SZTE Irinyi épület - Szeged, Tisza Lajos krt. 103
 - Résztvevők: Sziver Bence Dávid, Tomity Jaroslav, Allaga Dóra, Dehnhardt Tom Patrick
 - Érintett témák: Ismerkedés, projekttéma kiválasztása

2. megbeszélés:
 - Időpont: 2021.09.26.
 - Hely: SZTE Irinyi épület - Szeged, Tisza Lajos krt. 103
 - Résztvevők: Mindenki
 - Érintett témák: Projektterv írása

3. Megbeszélés:
 - Időpont: 2021.09.30.
 - Hely: Discord
 - Résztvevők: Mindenki
 - Érintett témák: Projektterv véglegesítés, további mérföldkövek feladatainak szétosztása

4. Megbeszélés:
 - Időpont: 2021.10.07.
 - Hely: Discord
 - Résztvevők: Mindenki
 - Érintett témák: 2. mérföldkő feladatainak átbeszélése

5. Megbeszélés:
 - Időpont: 2021.10.14.
 - Hely: Discord
 - Résztvevők: Mindenki
 - Érintett témák: 2. mérföldkő során felmerült problémák átbeszélése

### 7.3. Minőségbiztosítás

Az elkészült terveket a terveken nem dolgozó csapattársak közül átnézik, hogy megfelel-e a specifikációnak és az egyes diagramtípusok összhangban vannak-e egymással. A meglévő rendszerünk helyes működését a prototípusok bemutatása előtt a tesztelési dokumentumban leírtak végrehajtása alapján ellenőrizzük és összevetjük a specifikációval, hogy az elvárt eredményt kapjuk-e. További tesztelési lehetőségek: unit tesztek írása az egyes modulokhoz vagy a kód közös átnézése (code review) egy, a vizsgált modul programozásában nem résztvevő csapattaggal. Szoftverünk minőségét a végső leadás előtt javítani kell a rendszerünkre lefuttatott kódelemzés során kapott metrikaértékek és szabálysértések figyelembevételével.
Az alábbi lehetőségek vannak a szoftver megfelelő minőségének biztosítására:
- Specifikáció és tervek átnézése (kötelező)
- Teszttervek végrehajtása (kötelező)
- Unit tesztek írása (választható)
- Kód átnézése (választható)

### 7.4. Átadás, eredmények elfogadása

A projekt eredményeit Dr. Kertész Attila fogja elfogadni. A projektterven változásokat csak írásos kérés esetén, Dr. Kertész Attila engedélyével lehet tenni. A projekt eredményesnek bizonyul, ha specifikáció helyes és határidőn belül készül el. Az esetleges késések pontlevonást eredményeznek.
Az elfogadás feltételeire és beadás formájára vonatkozó részletes leírás a következő honlapon olvasható: https://okt.sed.hu/rf1/

### 7.5. Státuszjelentés

Minden leadásnál a projektmenedzser jelentést tesz a projekt haladásáról, és ha szükséges változásokat indítványoz a projektterven. Ezen kívül a megrendelő felszólítására a menedzser 3 munkanapon belül köteles leadni a jelentést. A gyakorlatvezetővel folytatott csapatmegbeszéléseken a megadott sablon alapján emlékeztetőt készít a csapat, amit a következő megbeszélésen áttekintenek és felmérik az eredményeket és teendőket. Továbbá gazdálkodnak az erőforrásokkal és szükség esetén a megrendelővel egyeztetnek a projektterv módosításáról.

## 8. A munka tartalma

### 8.1. Tervezett szoftverfolyamat modell és architektúra

A szoftver fejlesztése során az agilis fejlesztési modellt alkalmazzuk. A fejlesztés során nagy hangsúlyt fektetünk a folyamatos kommunikcióra. A fejlesztés során a szoftver specifikációi rugalmasan vátozhatnak, és ezzel a módszertannal tudunk a leggyorsabban alkalmazkodni az új elvárásokhoz.

A szoftver MVC alapú REST webszolgáltatásként működik. A szerver és a kliens függetlenek, csupán API végpontok segítségével kommunikálnak.

### 8.2. Átadandók és határidők
A főbb átadandók és határidők a projekt időtartama alatt a következők:


| Szállítandó |                 Neve                |  Határideje |
|:-----------:|:-----------------------------------:|:-----------:|
|      D1     |       Projektterv és útmutató       | 2022-10-02  |
|    P1+D2    | UML, DB, képernyőtervek és bemutató | 2022-10-16  |
|    P1+D3    |      Prototípus I. és bemutató      | 2022-11-06  |
|    P2+D4    |      Prototípus II. és bemutató     | 2022-11-27  |


## 9. Feladatlista

A következőkben a tervezett feladatok részletes összefoglalása található.

### 9.1. Projektterv (1. mérföldkő)

Ennek a feladatnak az a célja, hogy megvalósításhoz szükséges lépéseket, az ütemzést és a felelősöket meghatározzuk.

Részfeladatai a következők:

#### 9.1.1. Projektterv kitöltése

Felelős: Mindenki

Tartam:  4 nap

Erőforrásigény:  2 személynap/fő


#### 9.1.2. Bemutató elkészítése

Felelős: Sziver Bence Dávid

Tartam:  2 nap

Erőforrásigény:  1 személynap

### 9.2. UML és adatbázis tervek (2. mérföldkő)

Ennek a feladatnak az a célja, hogy a rendszerarchitektúrát, az adatbázist és webalkalmazás kinézetét megtervezzük.

Részfeladatai a következők:

#### 9.2.1. Use Case diagram

Felelős: Dehnhardt Tom Patrick

Tartam:  4 nap

Erőforrásigény:  3 személynap

#### 9.2.2. Class diagram

Felelős: Tomity Jaroslav

Tartam:  4 nap

Erőforrásigény:  2 személynap

#### 9.2.3. Sequence diagram

Felelős: Sziver Bence Dávid

Tartam:  3 nap

Erőforrásigény:  2 személynap

#### 9.2.4. Egyed-kapcsolat diagram adatbázishoz

Felelős: Kiss Mihály

Tartam:  4 nap

Erőforrásigény:  3 személynap

#### 9.2.5. Package diagram

Felelős: Dehnhardt Tom Patrick

Tartam:  4 nap

Erőforrásigény:  3 személynap

#### 9.2.6. Képernyőtervek

Felelős: Allaga Dóra

Tartam:  3 nap

Erőforrásigény:  1 személynap

#### 9.2.7. Bemutató elkészítése

Felelős: Allaga Dóra

Tartam:  1 nap

Erőforrásigény:  1 személynap

### 9.3. Prototípus I. (3. mérföldkő)

Ennek a feladatnak az a célja, hogy egy működő prototípust hozzunk létre, ahol a vállalt funkcionális követelmények nagy része már prezentálható állapotban van.

Részfeladatai a következők:

#### 9.3.1.  Felhasználói munkamenet üzleti logikája több jogosultsági szinttel (admin, vásárló)

Felelős: Tomity Jaroslav

Tartam:  5 nap

Erőforrásigény:  3 személynap

#### 9.3.2.  Felhasználói munkamenethez kapcsolódó GUI megvalósítása

Felelős: Tomity Jaroslav

Tartam:  4 nap

Erőforrásigény:  3 személynap

#### 9.3.3.  Felhasználói munkamenethez szükséges adatok létrehozása az adatbázisban

Felelős: Tomity Jaroslav

Tartam:  4 nap

Erőforrásigény:  3 személynap

#### 9.3.4.  Felhasználók kezeléséhez tartozó üzleti logika (listázása, módosítása, létrehozása, törlése)

Felelős: Sziver Bence Dávid

Tartam:  4 nap

Erőforrásigény:  3 személynap

#### 9.3.5.  Felhasználók kezeléséhez kapcsolódó GUI megvalósítása

Felelős: Sziver Bence Dávid

Tartam:  4 nap

Erőforrásigény:  3 személynap

#### 9.3.6.  Árukezeléshez tartozó üzleti logika (listázása, módosítása, létrehozása, törlése)

Felelős: Kiss Mihály

Tartam:  5 nap

Erőforrásigény:  4 személynap

#### 9.3.7.  Árukezeléshez kapcsolódó GUI megvalósítása

Felelős: Kiss Mihály

Tartam:  4 nap

Erőforrásigény:  3 személynap

#### 9.3.8.  Árukezeléshez szükséges adatok létrehozása az adatbázisban

Felelős: Kiss Mihály

Tartam:  4 nap

Erőforrásigény:  3 személynap

#### 9.3.9.  Kosár kezeléséhez tartozó üzleti logika (listázása, módosítása, létrehozása, törlése)

Felelős: Dehnhardt Tom Patrick

Tartam:  5 nap

Erőforrásigény:  4 személynap

#### 9.3.10.  Kosár kezeléséhez kapcsolódó GUI megvalósítása

Felelős: Dehnhardt Tom Patrick

Tartam:  5 nap

Erőforrásigény:  3 személynap

#### 9.3.11.  Kosár kezeléséhez szükséges adatok létrehozása az adatbázisban

Felelős: Dehnhardt Tom Patrick

Tartam:  3 nap

Erőforrásigény:  2 személynap

#### 9.3.12.  Rendelések kezeléséhez kapcsolódó üzleti logika (listázása, módosítása, létrehozása, törlése)

Felelős: Sziver Bence Dávid

Tartam:  4 nap

Erőforrásigény:  3 személynap

#### 9.3.13.  Rendelések kezeléséhez kapcsolódó GUI megvalósítása

Felelős: Sziver Bence Dávid

Tartam:  5 nap

Erőforrásigény:  4 személynap

#### 9.3.14.  Rendelések kezeléséhez szükséges adatok létrehozása az adatbázisban

Felelős: Tomity Jaroslav

Tartam:  3 nap

Erőforrásigény:  2 személynap

#### 9.3.15.  Árukeresés kezeléséhez tartozó üzleti logika (listázása, módosítása, létrehozása, törlése)

Felelős: Allaga Dóra

Tartam:  4 nap

Erőforrásigény:  3 személynap

#### 9.3.16.  Árukeresés kezeléséhez kapcsolódó GUI megvalósítása

Felelős: Allaga Dóra

Tartam:  5 nap

Erőforrásigény:  4 személynap

#### 9.3.17.  Áruszűrők kezeléséhez tartozó üzleti logika (listázása, módosítása, létrehozása, törlése)

Felelős: Allaga Dóra

Tartam:  3 nap

Erőforrásigény:  2 személynap

#### 9.3.18.  Áruszűrők kezeléséhez kapcsolódó GUI megvalósítása

Felelős: Allaga Dóra

Tartam:  5 nap

Erőforrásigény:  3 személynap

#### 9.3.19. Tesztelési dokumentum (TP, TC)

Felelős: Mindenki

Tartam:  3 nap

Erőforrásigény:  2 személynap/fő


#### 9.3.20. Bemutató elkészítése 

Felelős: Allaga Dóra

Tartam:  2 nap

Erőforrásigény:  2 személynap

### 9.4. Prototípus II. (4. mérföldkő)

Ennek a feladatnak az a célja, hogy az előző mérföldkő hiányzó funkcióit pótoljuk, illetve a hibásan működő funkciókat és az esetlegesen felmerülő új funkciókat megvalósítsuk. Továbbá az alkalmazás alapos tesztelése is a mérföldkőben történik.

Részfeladatai a következők:

#### 9.4.1. Javított minőségű prototípus új funkciókkal

Felelős: Tomity Jaroslav

Tartam:  5 nap

Erőforrásigény:  2 személynap

#### 9.4.2. Javított minőségű prototípus javított funkciókkal

Felelős: Dehnhardt Tom Patrick

Tartam:  5 nap

Erőforrásigény:  3 személynap

#### 9.4.3. Javított minőségű prototípus a korábbi hiányzó funkciókkal

Felelős: Kiss Mihály

Tartam:  5 nap

Erőforrásigény:  3 személynap

#### 9.4.4. Felhasználói munkamenet tesztelése (TP, TC, TR)

Felelős: Tommity Jaroslav

Tartam:  1 nap

Erőforrásigény:  1 személynap

#### 9.4.5. Árukészletek kezelésének tesztelése (TP, TC, TR)

Felelős: Kiss Mihály

Tartam:  1 nap

Erőforrásigény:  1 személynap

#### 9.4.6. Kosár kezelésének tesztelése (TP, TC, TR)

Felelős: Dehnhardt Tom Patrick

Tartam:  1 nap

Erőforrásigény:  1 személynap

#### 9.4.7. Rendelések kezelésének tesztelése (TP, TC, TR)

Felelős: Sziver Bence Dávid

Tartam:  1 nap

Erőforrásigény:  1 személynap

#### 9.4.8. Árukeresés kezelésének tesztelése (TP, TC, TR)

Felelős: Allaga Dóra

Tartam:  1 nap

Erőforrásigény:  1 személynap

#### 9.4.9. Áruszűrés kezelésének tesztelése (TP, TC, TR)

Felelős: Allaga Dóra

Tartam:  1 nap

Erőforrásigény:  1 személynap

#### 9.4.10. Bemutató elkészítése 

Felelős: Sziver Bence Dávid

Tartam:  1 nap

Erőforrásigény:  1 személynap

## 10. Részletes időbeosztás

![image](./webshop_gantt_diagram.png)

## 11. Projekt költségvetés

### 11.1. Részletes erőforrásigény (személynap)


|                     Név                    | 1. leadás - Projektterv | 2. leadás - UML és adatbázis | 3. leadás - Prototípus I. | 4. leadás - Prototípus II. | Összesen |
|:------------------------------------------:|:----------------------:|:--------------------------:|:-----------------------:|:------------------------:|:---------:|
|                     Sziver Bence Dávid           |           3          |             2            |           15          |            2           |    22   |
|                     Tomity Jaroslav           |           2          |             2            |           13          |            3           |    20   |
|                     Kiss Mihály             |           2          |             3            |           12          |            4           |    21   |
|                     Allaga Dóra             |           2          |             2            |           16          |            2           |    22   |
|                     Dehnhardt Tom Patrick             |           2          |             6            |           11          |            4           |    23   |


### 11.2. Részletes feladatszámok

|                     Név                    | 1. leadás - Projektterv | 2. leadás - UML és adatbázis | 3. leadás - Prototípus I. | 4. leadás - Prototípus II. | Összesen |
|:------------------------------------------:|:----------------------:|:--------------------------:|:-----------------------:|:------------------------:|:---------:|
|                     Sziver Bence Dávid            |           2          |             1            |           5           |            2           |    10   |
|                     Tomity Jaroslav           |           1          |             1            |           5           |            2           |    9   |
|                     Kiss Mihály             |           1          |             1            |           4           |            2           |    8   |
|                     Allaga Dóra             |           1          |             2            |           4          |            2           |    9   |
|                     Dehnhardt Tom Patrick             |           1          |             2            |           6          |            2           |    11   |

### 11.3. Részletes költségvetés

|                     Név                       | 1. leadás - Projektterv | 2. leadás - UML és adatbázis | 3. leadás - Prototípus I. | 4. leadás - Prototípus II. | Összesen |
|:---------------------------------------------:|:----------------------:|:--------------------------:|:-----------------------:|:------------------------:|:---------:|
|        Maximálisan választható pontszám %-ban |         10% (7)        |            30% (21)        |          50% (35)       |          30% (21)        | 100% (70) |
|                     Sziver Bence Dávid              |           7          |             13           |          35           |            15          |    70   |
|                     Tomity Jaroslav              |           7          |             17           |          28           |            18          |    70   |
|                     Kiss Mihály                |           7          |             17           |          25           |            21          |    70   |
|                     Allaga Dóra             |           7          |             13            |           35          |            15           |    70   |
|                     Dehnhardt Tom Patrick             |           7          |             21            |           21          |            21           |    70   |

Szeged, 2022-10-02.
