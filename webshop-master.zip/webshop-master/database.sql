--
-- PostgreSQL database dump
--

-- Dumped from database version 14.5
-- Dumped by pg_dump version 15.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: aruk; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.aruk (
    id character varying(100) NOT NULL,
    image character varying(100) NOT NULL,
    ar integer NOT NULL,
    raktaron integer NOT NULL,
    ertekelesek real DEFAULT 0,
    ertekelesek_szama integer DEFAULT 0
);


ALTER TABLE public.aruk OWNER TO doadmin;

--
-- Name: kosaruk; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.kosaruk (
    id character varying(100) NOT NULL,
    email character varying(100) NOT NULL,
    mennyiseg integer NOT NULL
);


ALTER TABLE public.kosaruk OWNER TO doadmin;

--
-- Name: rendelesek; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.rendelesek (
    rendeles_id integer NOT NULL,
    email character varying(100) NOT NULL,
    datum date NOT NULL
);


ALTER TABLE public.rendelesek OWNER TO doadmin;

--
-- Name: rendelesek_rendeles_id_seq; Type: SEQUENCE; Schema: public; Owner: doadmin
--

CREATE SEQUENCE public.rendelesek_rendeles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rendelesek_rendeles_id_seq OWNER TO doadmin;

--
-- Name: rendelesek_rendeles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: doadmin
--

ALTER SEQUENCE public.rendelesek_rendeles_id_seq OWNED BY public.rendelesek.rendeles_id;


--
-- Name: rendelt_aruk; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.rendelt_aruk (
    rendeles_id integer NOT NULL,
    aru_id character varying(100) NOT NULL,
    aru_image character varying(100) NOT NULL,
    aru_ar integer NOT NULL,
    mennyiseg integer NOT NULL
);


ALTER TABLE public.rendelt_aruk OWNER TO doadmin;

--
-- Name: users; Type: TABLE; Schema: public; Owner: doadmin
--

CREATE TABLE public.users (
    email character varying(100) NOT NULL,
    nev character varying(100) NOT NULL,
    lakcim character varying(100) NOT NULL,
    role character varying(100) NOT NULL,
    password character varying(100) NOT NULL
);


ALTER TABLE public.users OWNER TO doadmin;

--
-- Name: rendelesek rendeles_id; Type: DEFAULT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.rendelesek ALTER COLUMN rendeles_id SET DEFAULT nextval('public.rendelesek_rendeles_id_seq'::regclass);


--
-- Data for Name: aruk; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.aruk (id, image, ar, raktaron, ertekelesek, ertekelesek_szama) FROM stdin;
Uborka	/images/uborka.png	333	4	3	3
Cukor	/images/cukor.png	400	8	3.5	2
Lazac	/images/lazac.png	3000	7	4	3
Paprika	/images/paprika.png	200	3	2.5	2
Kifli	/images/kifli.png	40	2	2	2
Banán	/images/banan.png	200	4	2.5	2
Kenyér	/images/kenyer.png	750	11	4.5	2
Zsemle	/images/zsemle.png	50	3	4	4
Só	/images/so.png	401	6	3.5	4
Alma	/images/alma.png	400	10	3.8	4
Borsó	/images/borso.png	400	30	3.8	4
Csirkemell	/images/csirkemell.png	1700	7	2.3	3
\.


--
-- Data for Name: kosaruk; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.kosaruk (id, email, mennyiseg) FROM stdin;
Kifli	user@gmail.com	1
\.


--
-- Data for Name: rendelesek; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.rendelesek (rendeles_id, email, datum) FROM stdin;
\.


--
-- Data for Name: rendelt_aruk; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.rendelt_aruk (rendeles_id, aru_id, aru_image, aru_ar, mennyiseg) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: doadmin
--

COPY public.users (email, nev, lakcim, role, password) FROM stdin;
uj@gmail.com	Won Cu	Shiq, Helel 65	ROLE_USER	$2a$10$8ZYHhudvP7GbXT13jEZ83.///Bha2/tknmzf4HT6i.ZoI2CWuDDGC
adamin@gmail.com	Sanyi	messzefolde, kacat utca 6	ROLE_ADMIN	$2a$12$2cvO.POJZzyjVDoRPI6mR.hsPYvFGfWQ3kKRrhb3htwH2hmWNgGJG
lakatos@gmail.com	Laci	sargaut, zold utca 43	ROLE_USER	$2a$12$lWvs6ofztrCV67rsRBSH5OexqFuj425WSFbEMzUzsM3hm1hIlw8ka
sodro@gmail.com	Csacsi	libafolde, piroslabas utca 2	ROLE_USER	$2a$12$PRspMMaTvy9gRHoLcOR1qeYEMOysKjr43j35bVPqVvx9yQPGITq7q
jej@gmail.com	Sima Pacsi	Fidak, Ujsa 45	ROLE_USER	$2a$10$BZMrQwcp9sFA/nhG1JlIse71tBcp0jLb8ROwANAS068kkGDmHCIcm
hasznalo@gmail.com	PalcaUr	halasz, to utca 2	ROLE_USER	$2a$10$7XmI7kT8x24nvSMi0cCmWu9RyMMx54zVEAvV.rXDgpqMm5eP4gssy
ma@gmail.com	Dok Ika	Jalap, Help 21	ROLE_USER	$2a$10$RS7Afl595LR0zXTCAFCZYeIJnLotpkD5wYeI2I87vHfPiNRdmSVdC
user2@gmail.com	Kocsma Margit	Szeged, Nagy utca 3	ROLE_USER	$2a$10$F13lcLMlfWA4UwZNkkW30.cAAHFeEM8PIuIqfm8SDEULV2IZehXwy
eee@gmail.com	Mazsi Mazsa	Baks, Igen utca 1	ROLE_USER	$2a$10$tSwUHIVc2U3fJi/U6ep5iOoPy0mh6TR8g8YxxCKf8WodZkpVXX8yu
lol@gmail.com	San Hose	Mica, Ikor 1	ROLE_USER	$2a$10$jUN.d0IrNtTCTkecW7OlO.GwRkn1F7FVA6ywgrFiFB8kcuwWWMj1i
kapitany@gmail.com	Nagy Géza	Hatvan, Déri utca 3	ROLE_USER	$2a$10$NGfhhJ/yqYuPxuOvdFXD4e1HrR6wAwEs7PakwiFfjEzjrd1G/sEwK
reg@elek.com	Reg Elek	idk, utca 1	ROLE_USER	$2a$10$cmIL5yAAcL5YN/uFVm11FeuECUR01DEh5nmeZ1vtpcjVxd6hTruZC
grazie@gmail.com	Nagy Anna	Szeged, Nagy utca 15	ROLE_USER	$2a$10$RAHltRyuEY16dbR4q5zXYuOjI.Via9H2DOGA9wYnixX40.1TPFGY6
macska@gmail.com	Kis Nándor	Szeged, Macska utca 8	ROLE_USER	$2a$10$fXxxi2vzwMXTqRqo3vFtLeeBzx7hqR2f4QAk.VkgLqM2B5XzSGpem
hh@gmail.com	Macska Jancsi	Szeged, Vitéz utca 4	ROLE_USER	$2a$10$V1L4GYHQijEV3o8B07eq9Oy/YMtZy9.qZqQ.bqlVRV9zTKVXtdhP2
kosar@gmail.com	Kos Aron	Pornoapati,  Soos utca  69	ROLE_USER	$2a$10$qpHLoVYzOG5MiMJjIQmYpu7aviG7TgHL7lzYk.vZ8xSmNY7CV8HDG
kicsi@gmail.com	Pajkos Poni	Lecse, Hentes 12	ROLE_USER	$2a$10$YjPgIgZ7VcQKZYnmJnwJPuee.woFuxKDgxyxL5fx.itc2x5f7.NMW
nagy@gmail.com	Csani Tall	Csendes, Veges 42	ROLE_USER	$2a$10$1sHHZ7zF5EGDKDIT2gDiDeHZy0aSs95XE673DFl6Sn7NAwe6xfj7e
proba@gmail.com	Hello Mom	Kuka, Hal 8	ROLE_USER	$2a$10$znP0i6uupqmqbqoeMrjWG.8QPovZVZ6RNh7MahelvNd0kHGSCGXsG
probalom@gmail.com	Kicsi Vagyok	Polka, Giga 21	ROLE_USER	$2a$10$dV232u6ijMNsdHP6a51tuuRkiRu1h4zsWS0tEJ3byNdDmprq/TUUS
vegso@gmail.com	Nagy Csacsi	Kisfalva, Kufa 89	ROLE_USER	$2a$10$QULfQMlfZO9PIorX6U5dBukSo6MUCQv871TEga5li58x9eg5eZ0Iq
hope@gmail.com	Luke Skywalker	Vilagvege, Hold 19	ROLE_USER	$2a$10$hP5d0fF5YZaEHVOGtX/NruzenF7mN3HxVwHWQhDQKRwQg0AheiaQ2
na@gmail.com	Jdsa Das	Mars, Foldi 87	ROLE_USER	$2a$10$R8F.4j9ju8RazxzXjmGNH.zS6UmNkP5F80e6omc4p5RwEY4GNqUQ2
malac2@gmail.com	Malac Géza	Szeged, Nagy utca 2	ROLE_USER	$2a$10$TJwub9wJFo/AiCh75OPSk.tu2HQ88gF7YC3NFiy9xtL2koknbJqRW
malac@gmail.com	Giga Chad	Aprajafalva, Nagy utca 1	ROLE_USER	$2a$10$.gNaKPYV2vaI49TCYzVE2OrT5lQLTF80GOudFSIJ9XDOMYme.qW7y
admin@gmail.com	Teszt Elek	Szeged, Maros utca 7	ROLE_ADMIN	$2a$10$vAlye3TLp0QsCxYvDb1KPuqB9SB3qA.Xdki2ts7j7fRzqhAHkHFt2
tesztuser@gmail.com	Teszt New User	Teszt New város,   Teszt New utca   2	ROLE_USER	$2a$10$8g3BcerEDKopJg402QC5EOpnO.SvhdjevFjFiaP6OI5bzRHMEvqrO
user@gmail.com	Us Erik	Szeged, utca 69	ROLE_USER	$2a$10$vAlye3TLp0QsCxYvDb1KPuqB9SB3qA.Xdki2ts7j7fRzqhAHkHFt2
imel@aaaaaaaaaaaaaaaaaaaaaaaaaaaa	eae	aeae, aea 4	ROLE_USER	$2a$10$yK9Y5Jpx7alAd6SgML7yYu.kXfzQVtqjE1IjxEr6QoOmDz5LiHGZu
email@email2	ss	gggdfgdgd, eeee 4	ROLE_USER	$2a$10$I4e6KYu/VL9Vdnuo2I8L3u/HIMvKw.eNVTRlFoVwa.b/uMCB89N5W
\.


--
-- Name: rendelesek_rendeles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: doadmin
--

SELECT pg_catalog.setval('public.rendelesek_rendeles_id_seq', 3, true);


--
-- Name: aruk aruk_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.aruk
    ADD CONSTRAINT aruk_pkey PRIMARY KEY (id);


--
-- Name: kosaruk kosaruk_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.kosaruk
    ADD CONSTRAINT kosaruk_pkey PRIMARY KEY (id, email);


--
-- Name: rendelesek rendelesek_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.rendelesek
    ADD CONSTRAINT rendelesek_pkey PRIMARY KEY (rendeles_id);


--
-- Name: rendelt_aruk rendelt_aruk_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.rendelt_aruk
    ADD CONSTRAINT rendelt_aruk_pkey PRIMARY KEY (rendeles_id, aru_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (email);


--
-- Name: kosaruk kosaruk_email_fkey; Type: FK CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.kosaruk
    ADD CONSTRAINT kosaruk_email_fkey FOREIGN KEY (email) REFERENCES public.users(email) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: kosaruk kosaruk_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.kosaruk
    ADD CONSTRAINT kosaruk_id_fkey FOREIGN KEY (id) REFERENCES public.aruk(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: rendelesek rendelesek_email_fkey; Type: FK CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.rendelesek
    ADD CONSTRAINT rendelesek_email_fkey FOREIGN KEY (email) REFERENCES public.users(email) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: rendelt_aruk rendelt_aruk_rendeles_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: doadmin
--

ALTER TABLE ONLY public.rendelt_aruk
    ADD CONSTRAINT rendelt_aruk_rendeles_id_fkey FOREIGN KEY (rendeles_id) REFERENCES public.rendelesek(rendeles_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

