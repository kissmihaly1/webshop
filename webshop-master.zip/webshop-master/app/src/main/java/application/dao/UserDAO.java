package application.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Repository;
import application.model.User;

@Repository
public class UserDAO extends JdbcDaoSupport {

  @Autowired
  BCryptPasswordEncoder passwordEncoder;

  @Autowired
  DataSource dataSource;

  @PostConstruct
  private void initialize() {
    setDataSource(dataSource);
  }

  public void insertUser(User user) {
    String sql = "INSERT INTO users(email, nev, lakcim, role, password) VALUES (?, ?, ?, ?, ?)";
    getJdbcTemplate().update(sql, new Object[] {
      user.getEmail(), user.getNev(), user.getTelepules() + ", " + user.getUtca() + " " + user.getHazszam(), user.getRole(), passwordEncoder.encode(user.getPassword())
    });
  }

  public User getUserByEmail(String email) {
    String sql = "SELECT * FROM users WHERE email=?";
    List < Map < String, Object >> rows = getJdbcTemplate().queryForList(sql, email);

    List < User > result = new ArrayList < User > ();
    for (Map < String, Object > row: rows) {
      User user = new User();
      user.setEmail((String) row.get("email"));
      user.setNev((String) row.get("nev"));
      user.setTelepules(((String) row.get("lakcim")).split(",")[0]);
      user.setUtca(((String) row.get("lakcim")).split(",")[1].split("[0-9]")[0]);
      user.setHazszam(Integer.parseInt(((String) row.get("lakcim")).substring(((String) row.get("lakcim")).lastIndexOf(" ") + 1)));
      user.setRole((String) row.get("role"));
      user.setPassword((String) row.get("password"));

      result.add(user);
    }

    return result.get(0);
  }

  public boolean userExists(String email) {
    String sql = "SELECT * FROM users WHERE email=?";
    List < Map < String, Object >> rows = getJdbcTemplate().queryForList(sql, email);
    return rows.size() > 0;
  }

  public void deleteUser(String email) {
    String sql = "DELETE FROM users WHERE email=?";
    getJdbcTemplate().update(sql, email);
  }

  public void updateUser(String email, String name, String lakcim, String password) {
    String sql = "UPDATE users SET nev='" + name + "', lakcim='" + lakcim + "', password='" + passwordEncoder.encode(password) + "' WHERE email=?";
    getJdbcTemplate().update(sql, email);
  }

  public void updateUserOldPassword(String email, String name, String lakcim, String password) {
    String sql = "UPDATE users SET nev='" + name + "', lakcim='" + lakcim + "', password='" + password + "' WHERE email=?";
    getJdbcTemplate().update(sql, email);
  }

}