package application.dao;
import java.util.ArrayList;
import java.util.Map;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import application.model.Aru;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Repository;
import application.model.Kosar;

@Repository
public class KosarDAO extends JdbcDaoSupport {

    @Autowired
    DataSource dataSource;

    @Autowired
    private AruDAO aruDAO;

    @Autowired
    private UserDAO userDAO;

    @PostConstruct
    private void initialize() {
        setDataSource(dataSource);
    }

    public void insertKosar(Kosar kosar) {
        String sql = "INSERT INTO kosaruk(id, email, mennyiseg) VALUES (?, ?, ?)";
        getJdbcTemplate().update(sql, new Object[] {
                kosar.getId(), kosar.getEmail(), kosar.getMennyiseg()
        });
    }

    public List < Kosar > listKosar() {
        String email= SecurityContextHolder.getContext().getAuthentication().getName();
        String sql = "SELECT kosaruk.* FROM kosaruk, users WHERE kosaruk.email=users.email AND kosaruk.email='"+email+"' ORDER BY id";
        List < Map < String, Object >> rows = getJdbcTemplate().queryForList(sql);

        List < Kosar > result = new ArrayList < Kosar > ();
        for (Map < String, Object > row: rows) {
            Kosar kosar = new Kosar();
            kosar.setId((String) row.get("id"));
            kosar.setEmail((String) row.get("email"));
            kosar.setMennyiseg((Integer) row.get("mennyiseg"));
            result.add(kosar);
        }

        return result;
    }

    public boolean KosarbanVan(String id, String email) {
        String sql = "SELECT * FROM kosaruk WHERE id=? AND email=?";
        List < Map < String, Object >> rows = getJdbcTemplate().queryForList(sql, id, email);
        return rows.size() > 0;
    }

    public void deleteKosar(String id, String email) {
        String sql = "DELETE FROM kosaruk WHERE id=? AND email=?";
        getJdbcTemplate().update(sql, id, email);
    }

    public void deleteKosarFully(String email) {
        String sql = "DELETE FROM kosaruk WHERE email=?";
        getJdbcTemplate().update(sql, email);
    }

    public void updateKosar( String id, String email, int mennyiseg) {
        if (mennyiseg>0) {
            String sql = "UPDATE kosaruk SET mennyiseg='" + mennyiseg + "' WHERE id=? AND email=?";
            getJdbcTemplate().update(sql, id, email);
        }
    }

    public Kosar getKosar(String id, String email) {
        String sql = "SELECT * FROM kosaruk WHERE id=? AND email=?";
        List < Map < String, Object >> rows = getJdbcTemplate().queryForList(sql, id, email);

        List < Kosar > result = new ArrayList < Kosar > ();
        for (Map < String, Object > row: rows) {
            Kosar kosar = new Kosar();
            kosar.setId((String) row.get("id"));
            kosar.setEmail((String) row.get("email"));
            kosar.setMennyiseg((Integer) row.get("mennyiseg"));
            result.add(kosar);
        }

        return result.get(0);
    }

    public List<Kosar> getUserKosar(String email){
        String sql = "SELECT * FROM kosaruk WHERE email=?";
        List < Map < String, Object >> rows = getJdbcTemplate().queryForList(sql,email);
        List < Kosar > userkosar = new ArrayList < Kosar > ();

        for (Map < String, Object > row: rows) {
            Kosar kosar = new Kosar();
            kosar.setId((String) row.get("id"));
            kosar.setEmail((String) row.get("email"));
            kosar.setMennyiseg((Integer) row.get("mennyiseg"));
            userkosar.add(kosar);
        }
        return userkosar;
    }

    public void hoppaEzATermekMarAKosarbanVan(String id, int mennyiseg){
        if(mennyiseg<=aruDAO.getAruById(id).getRaktaron()){
            aruDAO.updateAru(id,aruDAO.getAruById(id).getImage(),aruDAO.getAruById(id).getAr(),aruDAO.getAruById(id).getRaktaron()-mennyiseg);
            updateKosar(id,SecurityContextHolder.getContext().getAuthentication().getName(),mennyiseg+getKosar(id, SecurityContextHolder.getContext().getAuthentication().getName()).getMennyiseg());
        }
    }


}
