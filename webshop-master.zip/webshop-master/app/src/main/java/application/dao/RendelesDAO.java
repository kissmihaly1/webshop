package application.dao;

import application.model.Kosar;
import application.model.Rendeles;
import application.model.RendeltAru;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Repository;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;
import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Repository
public class RendelesDAO extends JdbcDaoSupport {
    @Autowired
    DataSource dataSource;

    @PostConstruct
    private void initialize() {
        setDataSource(dataSource);
    }

    public List<Rendeles> listRendelesek(String email) {
        String sql = "SELECT * FROM rendelesek WHERE email=? ORDER BY datum DESC";
        List <Map< String, Object >> rows = getJdbcTemplate().queryForList(sql, email);

        List <Rendeles> result = new ArrayList< Rendeles >();
        for (Map < String, Object > row: rows) {
            Rendeles rendeles = new Rendeles();
            rendeles.setId((Integer) row.get("rendeles_id"));
            rendeles.setEmail((String) row.get("email"));
            rendeles.setDatum(((Date) row.get("datum")).toLocalDate());
            result.add(rendeles);
        }

        return result;
    }

    public List<Rendeles> listOsszesRendelesek() {
        String sql = "SELECT * FROM rendelesek";
        List <Map< String, Object >> rows = getJdbcTemplate().queryForList(sql);

        List <Rendeles> result = new ArrayList< Rendeles >();
        for (Map < String, Object > row: rows) {
            Rendeles rendeles = new Rendeles();
            rendeles.setId((Integer) row.get("rendeles_id"));
            rendeles.setEmail((String) row.get("email"));
            rendeles.setDatum(((Date) row.get("datum")).toLocalDate());
            result.add(rendeles);
        }

        return result;
    }

    public void insertRendelesek(Rendeles rendeles) {
        String sql = "INSERT INTO rendelesek(rendeles_id, email, datum) VALUES (DEFAULT, ?, ?)";

        getJdbcTemplate().update(sql, new Object[] {
                rendeles.getEmail(), rendeles.getDatum()
        });
    }

    public Integer listOsszar(Integer rendeles_id) {
        String sql = "SELECT rendelt_aruk.mennyiseg, rendelt_aruk.aru_ar FROM rendelt_aruk, rendelesek" +
                " WHERE rendelesek.rendeles_id=? AND rendelesek.rendeles_id=rendelt_aruk.rendeles_id";
        List <Map< String, Object >> rows = getJdbcTemplate().queryForList(sql, rendeles_id);

        Integer osszar = 0;
        for (Map < String, Object > row: rows) {
            osszar += (Integer) row.get("mennyiseg") * (Integer) row.get("aru_ar");
        }

        return osszar;
    }
}
