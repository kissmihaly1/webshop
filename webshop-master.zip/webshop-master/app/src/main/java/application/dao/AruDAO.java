package application.dao;

import java.util.ArrayList;
import java.util.Map;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import application.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Repository;
import application.model.Aru;

@Repository
public class AruDAO extends JdbcDaoSupport {

    @Autowired
    DataSource dataSource;

    @Autowired
    UserDAO userDAO;

    @PostConstruct
    private void initialize() {
        setDataSource(dataSource);
    }

    public void insertAru(Aru aru) {
        String sql = "INSERT INTO aruk(id, image, ar, raktaron) VALUES (?, ?, ?, ?)";

        getJdbcTemplate().update(sql, new Object[] {
                aru.getId(), aru.getImage(), aru.getAr(), aru.getRaktaron()
        });
    }

    public List<Aru> listAruk(Integer min, Integer max) {
        String sql = "SELECT * FROM aruk where ar <= ? and ar >= ?";
        List<Map<String, Object>> rows = getJdbcTemplate().queryForList(sql, max, min);

        List<Aru> result = new ArrayList<Aru>();
        for (Map<String, Object> row : rows) {
            Aru aru = new Aru();
            aru.setId((String) row.get("id"));
            aru.setImage((String) row.get("image"));
            aru.setAr((Integer) row.get("ar"));
            aru.setRaktaron((Integer) row.get("raktaron"));
            aru.setErtekelesek((Float) row.get("ertekelesek"));
            aru.setErtekelesek_szama((Integer) row.get("ertekelesek_szama"));
            String email = SecurityContextHolder.getContext().getAuthentication().getName();
            if ((Integer) row.get("raktaron") == 0) {
                if (userDAO.getUserByEmail(email).getRole().equals("ROLE_ADMIN")) {
                    result.add(aru);
                }
            } else {
                result.add(aru);
            }
        }

        return result;
    }

    public List<Aru> searchAruk(String id) {
        String sql = "SELECT * FROM aruk WHERE id=? ";
        List<Map<String, Object>> rows = getJdbcTemplate().queryForList(sql, id);

        List<Aru> result = new ArrayList<Aru>();
        for (Map<String, Object> row : rows) {
            Aru aru = new Aru();
            aru.setId((String) row.get("id"));
            aru.setImage((String) row.get("image"));
            aru.setAr((Integer) row.get("ar"));
            aru.setRaktaron((Integer) row.get("raktaron"));
            aru.setErtekelesek((Float) row.get("ertekelesek"));
            aru.setErtekelesek_szama((Integer) row.get("ertekelesek_szama"));
            if ((Integer) row.get("raktaron") == 0) {
                if (userDAO.getUserByEmail(SecurityContextHolder.getContext().getAuthentication().getName()).getRole()
                        .equals("ROLE_ADMIN")) {
                    result.add(aru);
                }
            } else {
                result.add(aru);
            }
        }
        return result;
    }

    public void deleteAru(String id) {
        String sql = "DELETE FROM aruk WHERE id=?";
        getJdbcTemplate().update(sql, id);
    }

    public void ratingAru(String id, Float ertekelesek, Integer ertekelesek_szama) {
        String sql = "UPDATE aruk SET ertekelesek='" + ertekelesek + "', ertekelesek_szama='" + ertekelesek_szama
                + "' WHERE id=?";
        getJdbcTemplate().update(sql, id);
    }

    public void updateAru(String id, String image, int ar, int raktaron) {
        String sql = "UPDATE aruk SET image='" + image + "', ar='" + ar + "', raktaron='" + raktaron + "' WHERE id=?";
        getJdbcTemplate().update(sql, id);
    }

    public Aru getAruById(String id) {
        String sql = "SELECT * FROM aruk WHERE id=?";
        List<Map<String, Object>> rows = getJdbcTemplate().queryForList(sql, id);

        List<Aru> result = new ArrayList<Aru>();
        for (Map<String, Object> row : rows) {
            Aru aru = new Aru();
            aru.setId((String) row.get("id"));
            aru.setImage((String) row.get("image"));
            aru.setAr((Integer) row.get("ar"));
            aru.setRaktaron((Integer) row.get("raktaron"));

            result.add(aru);
        }

        return result.get(0);
    }

}
