package application.dao;

import application.controller.AruController;
import application.model.Kosar;
import application.model.Rendeles;
import application.model.RendeltAru;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Repository
public class RendeltAruDAO extends JdbcDaoSupport {
    @Autowired
    DataSource dataSource;

    @Autowired
    private AruDAO aruDAO;

    @PostConstruct
    private void initialize() {
        setDataSource(dataSource);
    }

    public void insertRendeltAruk(List<Kosar> kosar, Integer rendeles_id) {
        for (int i = 0; i < kosar.size(); ++i) {
            String sql = "INSERT INTO rendelt_aruk(rendeles_id, aru_id, aru_image, aru_ar, mennyiseg) VALUES (?, ?, ?, ?, ?)";

            getJdbcTemplate().update(sql, new Object[] {
                    rendeles_id, kosar.get(i).getId(), aruDAO.getAruById(kosar.get(i).getId()).getImage(), aruDAO.getAruById(kosar.get(i).getId()).getAr(), kosar.get(i).getMennyiseg()
            });
        }
    }

    public List<RendeltAru> listRendeltAruk(String email) {
        String sql = "SELECT rendelt_aruk.* FROM rendelt_aruk, rendelesek WHERE rendelesek.email=? AND rendelesek.rendeles_id=rendelt_aruk.rendeles_id";
        List <Map< String, Object >> rows = getJdbcTemplate().queryForList(sql, email);

        List <RendeltAru> result = new ArrayList< RendeltAru>();
        for (Map < String, Object > row: rows) {
            RendeltAru rendeltAru = new RendeltAru();
            rendeltAru.setRendeles_id((Integer) row.get("rendeles_id"));
            rendeltAru.setAru_id((String) row.get("aru_id"));
            rendeltAru.setAru_image((String) row.get("aru_image"));
            rendeltAru.setAru_ar((Integer) row.get("aru_ar"));
            rendeltAru.setMennyiseg((Integer) row.get("mennyiseg"));
            result.add(rendeltAru);
        }

        return result;
    }
}
