package application.model;

import java.io.Serializable;

public class Aru implements Serializable {
    private static final long serialVersionUID = 1L;

    String id;
    String image;
    int ar;
    int raktaron;
    float ertekelesek;
    int ertekelesek_szama;

    public Aru() {
    }

    public Aru(String id, String image, int ar, int raktaron) {
        this.id = id;
        this.image = image;
        this.ar = ar;
        this.raktaron = raktaron;
    }

    public Aru(String image, int ar, int raktaron) {
        this.image = image;
        this.ar = ar;
        this.raktaron = raktaron;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public int getAr() {
        return ar;
    }

    public void setAr(int ar) {
        this.ar = ar;
    }

    public int getRaktaron() {
        return raktaron;
    }

    public void setRaktaron(int raktaron) {
        this.raktaron = raktaron;
    }

    public float getErtekelesek() {
        return ertekelesek;
    }

    public void setErtekelesek(float ertekelesek) {
        this.ertekelesek = ertekelesek;
    }

    public int getErtekelesek_szama() {
        return ertekelesek_szama;
    }

    public void setErtekelesek_szama(int ertekelesek_szama) {
        this.ertekelesek_szama = ertekelesek_szama;
    }

    @Override
    public String toString() {
        return "Aru{" + "id='" + id + '\'' + ", image='" + image + '\'' + ", ar=" + ar + ", raktaron=" + raktaron + '}';
    }
}
