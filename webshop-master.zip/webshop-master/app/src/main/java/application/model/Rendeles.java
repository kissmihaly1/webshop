package application.model;

import java.io.Serializable;
import java.time.LocalDate;

public class Rendeles implements Serializable {
    private static final long serialVersionUID = 1L;

    Integer id;
    String email;
    LocalDate datum;

    public Rendeles() {
    }

    public Rendeles(Integer id, String email, LocalDate datum) {
        this.id = id;
        this.email = email;
        this.datum = datum;
    }

    public Rendeles(String email, LocalDate datum) {
        this.email = email;
        this.datum = datum;
    }

    public Integer getId() {
        return id;
    }

    public String getEmail() {
        return email;
    }

    public LocalDate getDatum() {
        return datum;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setDatum(LocalDate datum) {
        this.datum = datum;
    }
}
