package application.model;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import javax.validation.constraints.*;

public class User implements UserDetails {

  private static final long serialVersionUID = 1L;
  String email;
  String nev;
  String telepules;
  String utca;
  Integer hazszam;
  String role;
  String password;

  public User() {}

  public User(String email, String nev, String telepules, String utca, Integer hazszam, String role, String password) {
    this.email = email;
    this.nev = nev;
    this.telepules = telepules;
    this.utca = utca;
    this.hazszam = hazszam;
    this.role = role;
    this.password = password;
  }

  public String getEmail() {
    return email;
  }

  public String getNev() {
    return nev;
  }

  public String getTelepules() {
    return telepules;
  }

  public String getUtca() {
    return utca;
  }

  public Integer getHazszam() {
    return hazszam;
  }

  public String getRole() {
    return role;
  }

  @Override
  public String getPassword() {
    return password;
  }

  public void setEmail(String email) {
    this.email = email;
  }

  public void setNev(String nev) {
    this.nev = nev;
  }

  public void setTelepules(String telepules) {
    this.telepules = telepules;
  }

  public void setUtca(String utca) {
    this.utca = utca;
  }

  public void setHazszam(Integer hazszam) {
    this.hazszam = hazszam;
  }

  public void setRole(String role) {
    this.role = role;
  }

  public void setPassword(String password) {
    this.password = password;
  }

  @Override
  public String toString() {
    return "User [email=" + email + ", nev=" + nev + ", telepules=" + telepules + ", utca=" + utca + ", hazszam=" + hazszam + ", role=" + role + ", password=" + password + "]";
  }

  @Override
  public boolean isAccountNonExpired() {
    return true;
  }

  @Override
  public boolean isAccountNonLocked() {
    return true;
  }

  @Override
  public boolean isCredentialsNonExpired() {
    return true;
  }

  @Override
  public boolean isEnabled() {
    return true;
  }

  @Override
  public Collection < ? extends GrantedAuthority > getAuthorities() {
    Set < GrantedAuthority > authorities = new HashSet < GrantedAuthority > ();
    authorities.add(new SimpleGrantedAuthority(this.role));
    return authorities;
  }

  @Override
  public String getUsername() {
    return this.email;
  }

}