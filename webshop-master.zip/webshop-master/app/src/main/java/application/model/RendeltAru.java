package application.model;

import java.io.Serializable;

public class RendeltAru implements Serializable {
    private static final long serialVersionUID = 1L;

    int rendeles_id;
    String aru_id;
    String aru_image;
    int aru_ar;
    int mennyiseg;

    public RendeltAru() {
    }

    public RendeltAru(int rendeles_id, String aru_id, String aru_image, int aru_ar, int mennyiseg) {
        this.rendeles_id = rendeles_id;
        this.aru_id = aru_id;
        this.aru_image = aru_image;
        this.aru_ar = aru_ar;
        this.mennyiseg = mennyiseg;
    }

    public int getRendeles_id() {
        return rendeles_id;
    }

    public void setRendeles_id(int rendeles_id) {
        this.rendeles_id = rendeles_id;
    }

    public String getAru_id() {
        return aru_id;
    }

    public void setAru_id(String aru_id) {
        this.aru_id = aru_id;
    }

    public String getAru_image() {
        return aru_image;
    }

    public void setAru_image(String aru_image) {
        this.aru_image = aru_image;
    }

    public int getAru_ar() {
        return aru_ar;
    }

    public void setAru_ar(int aru_ar) {
        this.aru_ar = aru_ar;
    }

    public int getMennyiseg() {
        return mennyiseg;
    }

    public void setMennyiseg(int mennyiseg) {
        this.mennyiseg = mennyiseg;
    }
}
