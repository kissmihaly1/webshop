package application.controller;

import application.dao.AruDAO;
import application.dao.RendelesDAO;
import application.dao.RendeltAruDAO;
import application.model.Aru;
import application.model.Kosar;
import application.model.Rendeles;
import application.model.RendeltAru;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.List;

@Controller
public class RendelesController {

    @Autowired
    private RendelesDAO rendelesDAO;
    @Autowired
    private RendeltAruDAO rendeltAruDAO;
    @Autowired
    private AruDAO aruDAO;
    private Integer rendeles_id;
    public static Integer osszar = 0;

    @GetMapping(value = "/rendelesek")
    public String listRendelesek(Model model) {
        List<Rendeles> rendelesList = rendelesDAO.listRendelesek(SecurityContextHolder.getContext().getAuthentication().getName());
        model.addAttribute("rendelesList", rendelesList);
        List<RendeltAru> rendeltAruList = rendeltAruDAO.listRendeltAruk(SecurityContextHolder.getContext().getAuthentication().getName());
        model.addAttribute("rendeltAruList", rendeltAruList);
        model.addAttribute("rendeles_id", rendeles_id);
        model.addAttribute("osszar",osszar);
        return "rendelesek";
    }

    @PostMapping(value="/rendeles_reszletei")
    public String reszletesRendelesek(Model model, @RequestParam("id") Integer id) {
        rendeles_id = id;
        osszar = rendelesDAO.listOsszar(rendeles_id);
        return listRendelesek(model);
    }
}
