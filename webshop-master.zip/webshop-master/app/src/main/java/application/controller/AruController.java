package application.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.springframework.aop.scope.ScopedProxyUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import application.dao.UserDAO;
import application.dao.AruDAO;
import application.model.Aru;
import application.model.User;

@Controller
public class AruController {

    @Autowired
    private AruDAO aruDAO;

    @Autowired
    private UserDAO userDAO;
    @Autowired
    private KosarController kosarController;

    @GetMapping(value = "/termekek")
    public String listAru(Model model, @RequestParam(value = "search_id", defaultValue = "") String id,
            @RequestParam(value = "min", defaultValue = "0") Integer min,
            @RequestParam(value = "max", defaultValue = "99999999") Integer max) {
        kosarController.rendeles_uresKosar = "";
        List<Aru> aruList;
        if (Objects.equals(id, "")) {
            aruList = aruDAO.listAruk(min, max);
        } else {
            id = id.substring(0, 1).toUpperCase() + id.substring(1);
            aruList = aruDAO.searchAruk(id);
        }
        model.addAttribute("aruk", aruList);
        if (aruList.isEmpty()) {
            model.addAttribute("invalid_search", "Nincs ilyen áru!");
        }
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication.getName().equals("anonymousUser")) {
            model.addAttribute("current_user", new User());
        } else {
            model.addAttribute("current_user", userDAO.getUserByEmail(authentication.getName()));
        }

        return "termekek";
    }

    @GetMapping(value = "/query_clear")
    public String query_clear(Model model) {
        return listAru(model, "", 0, Integer.MAX_VALUE);
    }

    @PostMapping(value = "/insertTermek")
    public String addAru(Model model, @RequestParam(value = "id", defaultValue = "") String id,
            @RequestParam(value = "image", defaultValue = "") String image,
            @RequestParam(value = "ar", defaultValue = "0") int ar,
            @RequestParam(value = "raktaron", defaultValue = "0") int raktaron) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String currentPrincipalName = authentication.getName();
        User user = userDAO.getUserByEmail(currentPrincipalName);
        Aru aru = new Aru(id, image, ar, raktaron);
        List<Aru> aruList;
        if (Objects.equals(id, "")) {
            aruList = aruDAO.listAruk(0, 9999);
        } else {
            id = id.substring(0, 1).toUpperCase() + id.substring(1);
            aruList = aruDAO.searchAruk(id);
        }
        model.addAttribute("aruk", aruList);
        if (aruList.isEmpty()) {
            if (!Objects.equals(id, "")) {
                aruDAO.insertAru(aru);
            }
        }

        return "redirect:/termekek";
    }

    @PostMapping(value = "/deleteTermek")
    public String deleteAru(@RequestParam("id") String id) {
        aruDAO.deleteAru(id);

        return "redirect:/termekek";
    }

    @PostMapping(value = "/update_rating")
    public String up_rating(@RequestParam("id") String id, @RequestParam("ertekelesek") Float ertekelesek,
            @RequestParam("ertekelesek_szama") Integer ertekelesek_szama, @RequestParam("rate") Integer rate) {
        ertekelesek = ((ertekelesek * ertekelesek_szama) + rate) / (ertekelesek_szama + 1);
        ertekelesek_szama++;
        ertekelesek = Math.round(ertekelesek * 10.0f) / 10.0f;
        aruDAO.ratingAru(id, ertekelesek, ertekelesek_szama);

        return "redirect:/termekek";
    }

    @PostMapping(value = "/modifyTermek")
    public String updateAru(@RequestParam(required = false, name = "id") String id,
            @RequestParam(name = "image", defaultValue = "") String image,
            @RequestParam(value = "ar", defaultValue = "0") int ar,
            @RequestParam(value = "raktaron", defaultValue = "0") int raktaron) {
        aruDAO.updateAru(id, image, ar, raktaron);

        return "redirect:/termekek";
    }

}
