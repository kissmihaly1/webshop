package application.controller;

import application.dao.KosarDAO;
import application.model.Kosar;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import application.dao.UserDAO;
import application.model.User;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Controller
public class UserController {
  @Autowired
  private UserDAO userDAO;

  @Autowired
  private KosarDAO kosarDAO;

  @Autowired
  private KosarController kosarController;

  private String jelszo_error;
  private String jelszo_hossz_error;
  private String reg_jelszo_error;
  private String reg_jelszo_hossz_error;
  private String delete_confirm;
  private String edit_success;
  private String user_exists;
  private String register_success;
  private List<String> formSave = new ArrayList<>();
  private List<String> regFormSave = new ArrayList<>();

  private void validation_reset() {
      regFormSave.clear();
      formSave.clear();
      jelszo_error = "";
      jelszo_hossz_error = "";
      reg_jelszo_error = "";
      reg_jelszo_hossz_error = "";
      delete_confirm = "";
      edit_success = "";
      user_exists = "";
      register_success = "";
  }


  @GetMapping("/login")
  public String login() {
    validation_reset();
    return "login";
  }
  

  @GetMapping("/profil")
  public String profil(Model model) {

      formSave.clear();
      for (int i = 0; i < 6; ++i) formSave.add("");

    String currentUser = SecurityContextHolder.getContext().getAuthentication().getName();
    User user = userDAO.getUserByEmail(currentUser);
    model.addAttribute("user", user);
    model.addAttribute("jelszo_error", jelszo_error);
    model.addAttribute("jelszo_hossz_error", jelszo_hossz_error);
    model.addAttribute("delete_confirm", delete_confirm);
    model.addAttribute("formSave", formSave);
    model.addAttribute("edit_success", edit_success);

    return "profil";
  }

  @GetMapping("/")
  public String index(Model model) {
    RendelesController.osszar = 0;
    model.addAttribute("register_success", register_success);
    register_success = "";
    return "login";
  }

  @GetMapping("/register")
  public String register(Model model) {
    if (regFormSave.isEmpty() || regFormSave.size() == 6) {
      for (int i = 0; i < 7; ++i) {
        regFormSave.add("");
      }
    }

    model.addAttribute("reg_jelszo_error", reg_jelszo_error);
    model.addAttribute("reg_jelszo_hossz_error", reg_jelszo_hossz_error);
    model.addAttribute("regFormSave", regFormSave);
    model.addAttribute("user_exists", user_exists);

    return "register";
  }

  @PostMapping(value = "/registeruser")
  public String registerUser(@RequestParam("email") String email, @RequestParam("nev") String nev, @RequestParam("telepules") String telepules,
                             @RequestParam("utca") String utca, @RequestParam("hazszam") Integer hazszam, @RequestParam("password") String password, @RequestParam("password_confirm")
                              String password_confirm) {
    validation_reset();
    if (userDAO.userExists(email)) {
      user_exists = "A felhasználó már létezik!";
    }
    if (!Objects.equals(password, password_confirm)) {
      reg_jelszo_error = "Nem egyeznek a jelszavak!";
    }
    if (password.length() < 5) {
      reg_jelszo_hossz_error = "Legalább 5 karakter hosszú jelszó szükséges!";
    }
    if (!reg_jelszo_error.isEmpty()  || !reg_jelszo_hossz_error.isEmpty() || !user_exists.isEmpty()) {
      regFormSave.add(email);
      regFormSave.add(nev);
      regFormSave.add(telepules);
      regFormSave.add(utca);
      regFormSave.add(hazszam.toString());
      regFormSave.add(password);
      regFormSave.add(password_confirm);
      return "redirect:/register";
    }

    User user = new User(email, nev, telepules, utca, hazszam, "ROLE_USER", password);
    userDAO.insertUser(user);
    register_success = "Sikeres Regisztráció! Jelentkezzen be!";
    return "redirect:/";
  }

  @PostMapping(value="/deleteuser")
  public String deleteUser() {
    List<Kosar> userkosar=kosarDAO.getUserKosar(SecurityContextHolder.getContext().getAuthentication().getName());
    for(Kosar kosar:userkosar){
      kosarController.deleteKosar(kosar.getId());
    }
    userDAO.deleteUser(SecurityContextHolder.getContext().getAuthentication().getName());
    delete_confirm = "";
    return "redirect:/";
  }

  @PostMapping(value="/deleteuser_confirm")
  public String deleteUserConfirm() {
    delete_confirm = "Biztosan törli a fiókot?";
    return "redirect:/profil";
  }

  @PostMapping(value="/deleteuser_reject")
  public String deleteUserReject() {
    delete_confirm = "";
    return "redirect:/profil";
  }

  @PostMapping(value="/modifyuser")
  public String modifyUser(@RequestParam("name") String name, @RequestParam("city") String city,
                           @RequestParam("street") String street, @RequestParam("house") Integer house,
                           @RequestParam("password") String password,
                           @RequestParam("password_confirm") String password_confirm) {
    validation_reset();
    if ((Objects.equals(name, "")) && (Objects.equals(city, "")) && (Objects.equals(street, "")) && house==null && (Objects.equals(password, "")) && (Objects.equals(password_confirm, ""))){
      edit_success = "Valamit bekene irni halo";
      return "redirect:/profil";
    }
    String email = SecurityContextHolder.getContext().getAuthentication().getName();
    if (Objects.equals(name, "")) {
      formSave.add("");
      name = userDAO.getUserByEmail(email).getNev();
    } else {
      formSave.add(name);
    }
    if (Objects.equals(city, "")) {
      formSave.add("");
      city = userDAO.getUserByEmail(email).getTelepules();
    } else {
      formSave.add(city);
    }
    if (Objects.equals(street, "")) {
      formSave.add("");
      street = userDAO.getUserByEmail(email).getUtca();
    } else {
      formSave.add(street);
    }
    if (house == null) {
      formSave.add("");
      house = userDAO.getUserByEmail(email).getHazszam();
    } else {
      formSave.add(house.toString());
    }
    if (Objects.equals(password, "")) {
      formSave.add("");
      password = userDAO.getUserByEmail(email).getPassword();
    } else {
      formSave.add(password);
    }
    if (password.length() < 5) {
      jelszo_hossz_error = "Legalább 5 karakter hosszú jelszó szükséges!";
    }
    if (Objects.equals(password_confirm, "")) {
      formSave.add("");
      password_confirm = userDAO.getUserByEmail(email).getPassword();
    } else {
      formSave.add(password_confirm);
    }
    if (!Objects.equals(password, password_confirm)) {
      jelszo_error = "Nem egyeznek a jelszavak!";
    }
    if (!jelszo_error.isEmpty()  || !jelszo_hossz_error.isEmpty()) {
      return "redirect:/profil";
    }
    if (Objects.equals(password, userDAO.getUserByEmail(email).getPassword())) {
      userDAO.updateUserOldPassword(email, name, city + ", " + street + " " + house, password);
    } else {
      userDAO.updateUser(email, name, city + ", " + street + " " + house, password);
    }
    edit_success = "Sikeres módosítás!";
    formSave.clear();
    return "redirect:/profil";
  }
  
  @PostMapping(value="/fail_login")
  public String handleFailedLogin() {
      
      return "redirect:/login?error";
  }
}