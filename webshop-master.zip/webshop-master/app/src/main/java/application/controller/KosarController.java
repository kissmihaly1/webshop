package application.controller;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import application.dao.*;
import application.model.*;
import org.springframework.aop.scope.ScopedProxyUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class KosarController {


    @Autowired
    private UserDAO userDAO;

    @Autowired
    private KosarDAO kosarDAO;

    @Autowired
    private AruDAO aruDAO;
    @Autowired
    private RendelesDAO rendelesDAO;
    @Autowired
    private RendeltAruDAO rendeltAruDAO;
    private String rendeles_confirm;
    public String rendeles_uresKosar;

    @GetMapping(value = "/kosar")
    public String listKosar(Model model) {
        List < Aru > aruList = new ArrayList<Aru>();
        List < Kosar > kosarList = kosarDAO.listKosar();
        List <Integer> osszar=new ArrayList<Integer>();
        model.addAttribute("kosaruk", kosarList);
        for (Kosar kosar: kosarList) {
            aruList.add(aruDAO.getAruById(kosar.getId()));
            osszar.add(kosar.getMennyiseg()*aruDAO.getAruById(kosar.getId()).getAr());
        }
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication.getName().equals("anonymousUser")) {
            model.addAttribute("current_user", new User());
        } else {
            model.addAttribute("current_user", userDAO.getUserByEmail(authentication.getName()));
        }
        model.addAttribute("aruk",aruList);
        model.addAttribute("osszar",osszar);
        model.addAttribute("rendeles_confirm", rendeles_confirm);
        model.addAttribute("rendeles_ures_kosar", rendeles_uresKosar);
        return "kosar";
    }

    @PostMapping(value = "/insertKosar")
    public String addAru(@RequestParam("id") String id, @RequestParam("mennyiseg") int mennyiseg) {
        if(mennyiseg<=aruDAO.getAruById(id).getRaktaron()) {
            if (!kosarDAO.KosarbanVan(id, SecurityContextHolder.getContext().getAuthentication().getName())){
                Kosar kosar = new Kosar(id, SecurityContextHolder.getContext().getAuthentication().getName(), mennyiseg);
                kosarDAO.insertKosar(kosar);aruDAO.updateAru(id,aruDAO.getAruById(id).getImage(),aruDAO.getAruById(id).getAr(),aruDAO.getAruById(id).getRaktaron()-mennyiseg);
            }else{
               kosarDAO.hoppaEzATermekMarAKosarbanVan(id,mennyiseg);
            }
        }else{
//            valami error
        }
        return "redirect:/termekek";
    }

    @PostMapping(value = "/deleteKosar")
    public String deleteKosar(@RequestParam("id") String id) {
        aruDAO.updateAru(id,aruDAO.getAruById(id).getImage(),aruDAO.getAruById(id).getAr(),aruDAO.getAruById(id).getRaktaron()+kosarDAO.getKosar(id,SecurityContextHolder.getContext().getAuthentication().getName()).getMennyiseg());
        kosarDAO.deleteKosar(id,SecurityContextHolder.getContext().getAuthentication().getName());
        return "redirect:/kosar";
    }

    @PostMapping(value = "/modifyKosar")
    public String updateKosar(@RequestParam(name="id") String id, @RequestParam("mennyiseg") int mennyiseg){
        if(mennyiseg<=kosarDAO.getKosar(id,SecurityContextHolder.getContext().getAuthentication().getName()).getMennyiseg()+aruDAO.getAruById(id).getRaktaron()){
            aruDAO.updateAru(id,aruDAO.getAruById(id).getImage(),aruDAO.getAruById(id).getAr(),aruDAO.getAruById(id).getRaktaron()+kosarDAO.getKosar(id,SecurityContextHolder.getContext().getAuthentication().getName()).getMennyiseg()-mennyiseg);
            kosarDAO.updateKosar(id,SecurityContextHolder.getContext().getAuthentication().getName(),mennyiseg);
        }
        return "redirect:/kosar";
    }

    @GetMapping(value = "/rendeles")
    public String rendeles(Model model) {
        rendeles_confirm = "Biztosan véglegesíti a rendelést?";
        rendeles_uresKosar = "";
        return listKosar(model);
    }

    @GetMapping(value = "/rendeles_reject")
    public String rendeles_reject(Model model) {
        rendeles_confirm = "";
        return listKosar(model);
    }

    @PostMapping(value = "/rendeles_accept")
    public String rendeles_accept() {
        rendeles_confirm = "";
        rendeles_uresKosar = "";
        if (kosarDAO.listKosar().isEmpty()) {
            rendeles_uresKosar = "Üres a kosár! Nem lehet rendelni!";
            return "redirect:/kosar";
        }
        Rendeles rendeles = new Rendeles(SecurityContextHolder.getContext().getAuthentication().getName(), java.time.LocalDate.now());
        rendelesDAO.insertRendelesek(rendeles);
        List<Rendeles> rendelesek = rendelesDAO.listOsszesRendelesek();
        rendeltAruDAO.insertRendeltAruk(kosarDAO.listKosar(), rendelesek.get(rendelesek.size() - 1).getId());
        kosarDAO.deleteKosarFully(SecurityContextHolder.getContext().getAuthentication().getName());

        return "redirect:/rendelesek";
    }

}
